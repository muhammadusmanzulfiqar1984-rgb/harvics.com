# PACKAGE MANIFEST

This package contains the repository-wide Cursor constitution and the canonical CRM module constitution.

1. MASTER_CURSOR_CONSTITUTION.md
   Repository-wide build rules and module-constitution standard.

2. 05-CRM-SALES_MASTER.md
   Full CRM + Sales module constitution supplied by the project source material.

IMPORTANT:
- Do not infer unverified implementation from specification.
- Preserve IMPLEMENTED / SPECIFIED / TARGET / UNKNOWN / TBD labels.
- Use the CRM document as the depth benchmark for future module constitutions.
