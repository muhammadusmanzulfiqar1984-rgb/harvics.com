# HARVICS OS — CURSOR DEVELOPMENT MASTER CONSTITUTION
## Repository-Wide Build Authority

**Classification:** Confidential — Internal Build Document  
**System:** Harvics OS / Harvics Universe  
**Purpose:** Master development authority for Cursor  
**Authority:** Repository-wide architectural rules  
**Benchmark specification:** `05-CRM-SALES_MASTER.md`

---

## 0. READ THIS FIRST

Cursor MUST read this file before modifying Harvics OS.

Cursor MUST then read the relevant module constitution before modifying a module.

The module constitution is authoritative for that module's:
- scope
- ownership
- entities
- workflows
- API contracts
- permissions
- AI behaviour
- governance
- audit
- failure/recovery
- UI
- acceptance criteria
- implementation status

The CRM + Sales constitution included in this package is the reference standard for the required depth and discipline of all future module constitutions.

**Do not downgrade module specifications into generic CRUD descriptions.**

---

## 1. SOURCE-OF-TRUTH DISCIPLINE

When sources conflict, use the repository's established authority hierarchy.

For each claim, distinguish:

- `IMPLEMENTED` — verified in actual repository/schema/API.
- `SPECIFIED` — architecturally defined but not verified as implemented.
- `TARGET` — future intended capability.
- `UNKNOWN` — specification exists but implementation is unverified.
- `TBD` — source does not establish the decision.

Never convert `SPECIFIED` or `TARGET` into `IMPLEMENTED`.

Never present scaffolding as a production capability.

Never invent missing certainty.

---

## 2. ARCHITECTURAL PRINCIPLES

### 2.1 Domain ownership

Every material business object has one authoritative owning domain.

Other domains:
- read through typed contracts or approved read models
- consume domain events
- do not directly mutate another domain's authoritative records

### 2.2 Transaction integrity

A business mutation must be treated as:

```text
Authentication
→ Authorisation
→ Tenant isolation
→ Schema validation
→ Master-data validation
→ Business rules
→ AI decision where applicable
→ Governance where applicable
→ Human approval where required
→ Transactional write
→ Domain event
→ Notification
→ Immutable audit
→ Typed response
```

The exact controls depend on the module constitution.

### 2.3 Tenant isolation

`tenantId` comes from authenticated server-side context.

Never trust tenant identity supplied by the request body.

Every tenant-owned query must enforce tenant scope.

### 2.4 Auditability

Material mutations must produce immutable audit records.

Audit records must preserve enough information to establish:
- actor
- role
- tenant
- action
- object
- timestamp
- correlation/request identity
- before/after material state
- governance decision where applicable
- AI influence where applicable

### 2.5 AI

AI is not an uncontrolled application layer.

AI:
- does not perform arbitrary SQL
- does not bypass governance
- does not fabricate unavailable data
- does not silently become authoritative where the module constitution says human approval is required
- must use typed tools/contracts
- must record model/version/input reference when influencing a governed action
- must have an explicit failure behaviour

### 2.6 Governance

Governance is server-side.

A UI indication is not governance.

Where a module constitution requires governance, the execution path must prove that the governance decision occurs before the controlled mutation.

---

## 3. STATUS DISCIPLINE

A route existing does not mean the product is complete.

Use the graduation model:

| Stage | Meaning |
|---|---|
| S0 | Catalogue |
| S1 | Generic/scaffold |
| S2 | Domain API |
| S3 | Operator UI |
| S4 | Controlled: auth, audit, governance, RBAC and tested execution path |

Do not describe S0/S1 as live production functionality.

---

## 4. CROSS-DOMAIN CONTRACT RULE

Modules communicate through explicit contracts.

Preferred patterns:

```text
Synchronous:
Domain API → typed request/response → validated result

Asynchronous:
Domain event → event bus → consumer → idempotent handler
```

Events must be:
- versionable
- traceable
- tenant-scoped where applicable
- idempotently consumable
- auditable

Do not create hidden database coupling between domains.

---

## 5. DATA ARCHITECTURE

Prisma/domain models are authoritative for currently implemented relational state.

Do not create duplicate authoritative tables merely because another route already exists.

Where duplicate systems exist:
1. identify the canonical model
2. identify migration path
3. deprecate the duplicate
4. preserve historical data where required
5. update consumers
6. test the cut-over

Never silently maintain two competing systems of record.

---

## 6. API STANDARD

Unless a module constitution explicitly specifies otherwise:

```text
Success:
{
  data: T,
  meta: {
    requestId,
    timestamp
  }
}

List:
{
  data: T[],
  meta: {
    requestId,
    timestamp,
    page,
    perPage,
    total
  }
}

Error:
{
  error: {
    code,
    message,
    field?
  },
  meta: {
    requestId,
    timestamp
  }
}
```

HTTP semantics must be correct:

- 400 validation
- 401 authentication
- 403 authorisation
- 404 not found
- 409 conflict/idempotency
- 422 where domain validation specifically requires it
- 429 rate limiting
- 5xx server/integration failure

Do not return HTTP 200 containing an application error.

---

## 7. IDEMPOTENCY

Every financially or operationally material mutation must explicitly consider duplicate execution.

Examples include:
- orders
- payments
- invoices
- settlements
- procurement commitments
- inventory movements
- external integrations

If a module constitution specifies an idempotency key, it is mandatory.

---

## 8. FAILURE BEHAVIOUR

External dependency failure must have an explicit policy.

Possible policies:

- fail closed
- fail open
- retry
- queue
- pending state
- human escalation

Never silently substitute:
- stale financial rates
- invented inventory
- fabricated AI output
- default tax
- fake approval
- synthetic business metrics

---

## 9. UI RULES

The interface is not allowed to manufacture business truth.

Therefore:

- no fake KPIs
- no invented pipeline
- no fabricated transactions
- no fake customer counts
- no placeholder values presented as real
- loading states must resolve against actual data
- errors must be explicit
- empty states are preferable to invented data
- module-specific routes must be used instead of generic placeholder screens once a module has a real UI

The UI must represent the actual implementation state.

---

## 10. SECURITY BASELINE

Every module must comply with the repository security architecture.

Minimum expectations:

- authenticated API access
- server-side authorisation
- tenant isolation
- least privilege
- secrets outside source/client bundles
- immutable audit for material mutations
- no sensitive payment credentials stored in ordinary business modules
- input validation
- output filtering
- rate limiting where required
- secure external integration credentials
- traceable actor identity

Security exceptions must be explicit and documented.

---

## 11. OBSERVABILITY

Every production workflow should be traceable.

At minimum:

```text
requestId
correlationId
tenantId
actorId
action
domain object
result
failure reason
```

Cross-module flows must preserve correlation identity.

Example:

```text
CRM Order
→ Inventory Reservation
→ Logistics
→ Finance Invoice
→ HPay Payment
→ Ledger
```

A production failure must be diagnosable without reconstructing the entire system manually.

---

## 12. MODULE CONSTITUTION STANDARD

Every major Harvics module must eventually have a constitution equivalent in depth to:

`05-CRM-SALES_MASTER.md`

The minimum structure is:

1. Module position in Harvics organism
2. Source-of-truth hierarchy
3. Honest implementation state
4. Ownership/boundary rules
5. Complete entity model
6. Workflow specifications at implementation depth
7. End-to-end value stream
8. API contract
9. AI integration
10. Neural Governance integration
11. RBAC
12. S0→S4 graduation roadmap
13. UI architecture
14. Notifications
15. Audit requirements
16. Failure/recovery
17. Reporting/KPIs
18. Security/compliance
19. Dependency map
20. Cursor prohibitions
21. S4 acceptance criteria
22. Document maintenance

If a source does not provide a section's details, mark it `TBD`, `UNKNOWN`, or `TARGET`. Do not fabricate details.

---

## 13. CRM BENCHMARK

`05-CRM-SALES_MASTER.md` is included in this package as the canonical CRM specification.

It establishes the required level of precision for a serious Harvics module constitution, including:

- Customer
- Contact
- Lead
- Deal
- Quote
- QuoteLine
- SalesOrder
- SalesOrderLine
- CrmActivity
- CreditLimit
- PriceList
- Subscription
- Rebate
- Return
- SupportTicket
- SLA

It also defines:
- Lead-to-Cash
- Quote-to-Cash
- API contracts
- AI scoring
- CPQ AI
- Neural Governance
- RBAC
- notifications
- audit
- failure/recovery
- KPIs
- security
- dependency boundaries
- S4 acceptance criteria

Cursor must preserve this level of specificity when extending the architecture.

---

## 14. CURSOR EXECUTION RULES

Before changing code:

1. Read this master constitution.
2. Read the relevant module constitution.
3. Inspect the existing repository.
4. Inspect the Prisma schema.
5. Inspect existing API routes.
6. Inspect existing UI routes.
7. Determine actual implementation status.
8. Identify conflicts/duplicates.
9. Plan the smallest coherent change.
10. Implement.
11. Run type/build/lint/test checks applicable to the repository.
12. Verify security and tenant isolation.
13. Verify audit/governance where required.
14. Update status documentation only after implementation is verified.

Do not rewrite unrelated modules merely because a cleaner architecture is possible.

Do not introduce complexity without a business or technical reason.

Do not create speculative infrastructure merely to make the architecture look complete.

---

## 15. VALUE-STREAM FIRST BUILDING

The system should be built around complete commercial value streams, not disconnected screens.

The CRM constitution demonstrates the primary commercial highway:

```text
Lead
→ Customer
→ Deal
→ Quote
→ Sales Order
→ Inventory
→ Fulfillment
→ Invoice
→ Payment
→ Ledger
→ Data Ocean
→ AI learning
```

When implementing another domain, preserve the same principle:

**finish the executable business path before expanding feature breadth.**

---

## 16. DEFINITION OF DONE

A module or feature is not done because:

- a page exists
- an endpoint returns 200
- a Prisma model exists
- a generic factory can create records
- a button appears
- an AI response is displayed

It is done only when the applicable acceptance criteria are satisfied.

At S4, verify:

```text
Functional correctness
+
Data integrity
+
Tenant isolation
+
Authentication
+
Authorisation
+
Audit
+
Governance where required
+
AI controls where applicable
+
Observability
+
Failure/recovery
+
Tests
```

---

## 17. PROHIBITIONS

Cursor MUST NOT:

- invent implementation status
- invent financial data
- invent customer data
- create duplicate systems of record without an explicit migration plan
- bypass tenant isolation
- trust client-supplied tenant identity
- bypass governance
- fabricate AI results
- use AI as an uncontrolled database writer
- silently swallow integration failures
- hard-delete financially relevant history
- represent scaffolding as production
- replace explicit domain logic with generic CRUD when a module constitution defines business rules
- change unrelated architecture merely for aesthetic consistency
- mark S4 without evidence

---

## 18. CURRENT PACKAGE CONTENT

```text
HARVICS_FINAL_CURSOR_MASTER/
│
├── MASTER_CURSOR_CONSTITUTION.md
└── 05-CRM-SALES_MASTER.md
```

The CRM constitution is intentionally preserved as a separate authority document rather than flattened into the master.

As additional module constitutions are validated, add them beside it:

```text
01-FINANCE_MASTER.md
02-...
03-HPAY_MASTER.md
...
05-CRM-SALES_MASTER.md
...
```

The master constitution governs the repository.

The module constitution governs its domain.

---

## 19. FINAL CURSOR DIRECTIVE

Build Harvics as one coherent operating system.

Do not build a collection of attractive screens.

Do not confuse architecture diagrams with executable systems.

Do not confuse generated code with verified capability.

Do not confuse AI assistance with autonomous authority.

Every material business process must have:

```text
OWNER
→ STATE
→ RULES
→ DATA
→ API
→ GOVERNANCE
→ AUDIT
→ EVENT
→ FAILURE MODE
→ OBSERVABILITY
→ TEST
→ ACCEPTANCE GATE
```

When the source material is silent, mark the gap.

When the repository contradicts the specification, expose the contradiction.

When a feature is not actually implemented, say so.

When a workflow is commercially critical, build the end-to-end path before peripheral features.

**The objective is not maximum code.**

**The objective is a coherent, governed, auditable, commercially executable Harvics OS.**

---

END OF MASTER CONSTITUTION
