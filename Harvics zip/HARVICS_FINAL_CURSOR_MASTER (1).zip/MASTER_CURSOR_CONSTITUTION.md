# HARVICS OS — UNIFIED MASTER CURSOR CONSTITUTION & SYSTEM ARCHITECTURE
## Master Execution Specification & Build Constitution · Revision 4.0
**System:** Harvics OS / Harvics Universe / Harvics Global Ventures
**Classification:** Confidential — Internal Master Instruction Document
**Target:** AI-Native Global B2B Trade & Enterprise Operating Infrastructure Platform
**Document Authority:** Supreme Technical Source of Truth for Cursor, Developers, and AI Coding Agents

---

## 0. EXECUTIVE DIRECTIVE & ARCHITECTURAL FOUNDATION

Build Harvics OS as an **AI-native global B2B trade and enterprise operating infrastructure platform**, not as a collection of 71 unrelated, shallow CRUD modules.

```text
                    HARVEY ENGINE (Intelligence & Decision Layer)
                         ↓
                    DATA OCEAN (Bronze / Silver / Gold Feature Layers)
                         ↓
                    HARVICS OS (Enterprise Orchestration Engine)
                  /      |       \
                 /       |        \
          HARVICS APPS  HPay   HARVICSTRADE (Trade Execution Wedge)
                 \       |        /
                  \      |       /
                   ENTERPRISE / TRADE ACTIVITY
                         ↓
                    DATA FEEDBACK
                         ↓
                    AI IMPROVEMENT
```

### Critical Architecture Directive
Do not build 71 independent modules. Build the **executable system graph**. The platform must render two end-to-end commercial highways operational:

1. **Lead-to-Cash Highway:**
   `LEAD` → `QUALIFICATION` → `OPPORTUNITY` → `QUOTE (CPQ)` → `CONTRACT` → `SALES ORDER` → `CREDIT CHECK` → `INVENTORY ALLOCATION` → `SHIPMENT` → `DELIVERY (POD)` → `INVOICE` → `PAYMENT (HPAY)` → `DOUBLE-ENTRY LEDGER` → `DATA OCEAN` → `AI LEARNING`

2. **Source-to-Pay Highway:**
   `PURCHASE REQUEST` → `APPROVAL` → `RFQ` → `SUPPLIER QUOTE` → `COMPARISON` → `PURCHASE ORDER` → `GOODS RECEIPT (GRN)` → `QUALITY INSPECTION` → `SUPPLIER INVOICE` → `3-WAY MATCH` → `GOVERNANCE` → `PAYMENT` → `LEDGER`

---

## 1. SOURCE-OF-TRUTH HIERARCHY & TAXONOMY ALIGNMENT

When source materials overlap or conflict, resolve in this exact sequence:

1. **This File (`MASTER_CURSOR_CONSTITUTION.md`)** — supreme operational instruction.
2. **`05-CRM-SALES_MASTER.md`** — deep domain authority for Module 05.
3. **`module-registry.json`** — canonical module status flags.
4. **Harvics OS Code Audit (August 2026)** — as-built reality of the codebase.
5. **Existing Prisma Schema (`prisma/schema.prisma`)** — database truth.

### Taxonomy Normalization
- **32 Product Modules:** Bounded commercial products.
- **20 Production OS Domains:** Backend domain engines and micro-services.
- **71 Catalogue Modules:** Registry navigation & workspace layout.
- **Rule:** A route or JSON scaffold existing in the registry is **S1 (Scaffold)**, NOT a live production product (S4/S5). Never confuse catalog count with production readiness.

### Module Graduation Path (S0 → S5)
Every feature or module must progress strictly through these stages:
- `S0 Catalogue`: Name, band, and route defined in the registry.
- `S1 Factory`: Generic JSON CRUD at `/api/m/:id` (Scaffold only — never present as product).
- `S2 Domain API`: Dedicated Prisma models and Express domain controller.
- `S3 Operator UI`: Dedicated Next.js workspace page with real DB records (no mock KPIs).
- `S4 Controlled`: Auth, RBAC, tenant isolation, audit logging, and server-side Neural Governance on writes.
- `S5 Production`: Full test suite, idempotency, failure recovery, and real transaction validation.

---

## 2. THE FOUR ZOOM LEVELS

Every feature implementation must be designed through four zoom levels:

1. **MOON (Organism):** Harvics OS enterprise layer, Data Ocean, Harvey AI, HPay, Harvoice, Globalisation (Soul), and Neural Governance.
2. **EARTH (Module System):** Cross-module highways (Lead-to-Cash, Procure-to-Pay, Trade Execution).
3. **NEW YORK (Module):** Bounded domain context (Master Data, Operations, Workflows, Compliance, Reporting, AI, Integrations, Security).
4. **MANHATTAN (Workflow):**
   `Trigger` → `Validation` → `Data Read` → `AI Decision` → `Neural Governance` → `Human Approval` → `API Execution` → `Database Write` → `Event Publish` → `Audit Trail`

---

## 3. AS-BUILT SYSTEM REALITY & CODEBASE AUDIT (August 2026)

```text
VERIFIED IMPLEMENTED IN CODEBASE (S3)
───────────────────────────────────────────────────────────────────────────
✓ Prisma Models: Customer, Lead, Deal, CrmActivity                   [IMPLEMENTED]
✓ Wave 8 Smart CRM APIs: /api/wave8/*                                 [IMPLEMENTED]
✓ Classic CRM Customer API: /api/crm/customers                        [IMPLEMENTED]
✓ Wave 3 Pipeline API: /api/wave3/crm/pipeline                        [IMPLEMENTED]
✓ Operator Workspace UI: /[locale]/os/crm, /smart, /customers, /pipeline [IMPLEMENTED]
✓ AI Lead Scoring & Email Draft Generation via Groq (Llama 3.3 70B)   [IMPLEMENTED]
✓ Auth: Bearer JWT in localStorage (requireAuthScope + crmPermissionGate) [IMPLEMENTED]

KNOWN ARCHITECTURAL DEFECTS TO FIX IMMEDIATELY
───────────────────────────────────────────────────────────────────────────
1. DUAL LEAD TABLE GAP: /api/crm/leads and /api/wave8/leads use separate stage enums.
   --> FIX: Unify on Wave 8 Lead schema as the single canonical Lead model.
2. SECURITY GAP: /api/v2/* auth scope exhibits null actorId/actorRole.
   --> FIX: Enforce mandatory JWT claims on all /api/v2/* handlers.
3. MOCK KPIS: /os/crm/legacy displays hardcoded "$4.82M pipeline" and "847 accounts".
   --> FIX: Remove all mock KPI displays; show real DB aggregates or empty state.
4. DUPLICATE CUSTOMER WRITERS: /api/crm/customers vs Wave 8 convert vs /api/modules/demo.
   --> FIX: Deprecate demo controllers; route all customer creation through Module 05 API.
```

---

## 4. CORE SYSTEM INVARIANTS & CODING STANDARDS

1. **Monetary Values:** ALWAYS store as `BIGINT` minor currency units (e.g., Cents, Paisa) or exact `Decimal(18, 4)`. NEVER use floating-point numbers (`FLOAT` or `DOUBLE`) for financial amounts.
2. **Double-Entry Ledger:** All financial movements must create immutable debit/credit entry pairs. Never mutate a balance column directly (`balance = balance + X` is FORBIDDEN).
3. **Idempotency:** Every financial, payment, invoice, and order operation MUST require an `idempotencyKey` header or payload field to prevent duplicate execution on network retries.
4. **Timestamps & Identifiers:** Primary keys must use `UUIDv4` or `CUID`. All timestamps must be stored in UTC (`ISO-8601`).
5. **Tenant Scoping:** Every domain query and database write MUST include `tenantId` extracted from authenticated JWT context. Accepting `tenantId` from client payload is strictly FORBIDDEN.
6. **Soft Deletion:** Never perform SQL `DELETE` on core entities (`Customer`, `Lead`, `Deal`, `Quote`, `SalesOrder`). Use `deletedAt` timestamp.
7. **No Fake Data:** Never populate UI components or dashboards with hardcoded stub data. If records do not exist, render `EmptyState`.

---

## 5. PLATFORM SERVICES & SHARED CORE

### 5.1 Neural Governance (Server-Side Control Plane)
Neural Governance executes **server-side** before every state-changing mutation (`POST`, `PUT`, `PATCH`, `DELETE`):

```text
Mutation Request
       ↓
Neural Governance Evaluation
 ├── 1. Legal Check       (Export control, country risk, entity verification)
 ├── 2. Budget Check      (Delegated authority limits, discount caps)
 ├── 3. Contract Check    (Framework agreements, pricing rules)
 ├── 4. Security Check    (RBAC permissions, MFA, tenant context)
 └── 5. Compliance Check  (AML, KYB, sanctions screening)
       ↓
  ┌────┴──────────────┐
  ↓                   ↓
APPROVED           BLOCKED / ESCALATED
  ↓                   ↓
Execute Write      Abort Transaction & Return Audit Explanation
```

### 5.2 AI Engine & Harvey Controlled Execution
- **Typed Tool Pattern:** LLMs (Groq / Gemini / Claude) NEVER receive unrestricted SQL or direct database access.
- **Execution Path:** `LLM Intent` → `Typed Schema` → `Permission Check` → `Neural Governance` → `Transactional API` → `Audit Record`.
- **AI Audit Record:** Every AI-influenced write must record `modelName`, `modelVersion`, `confidenceScore`, `inputReference`, and `governanceResult`.

### 5.3 Data Ocean Layers
- **Bronze Layer:** Append-only raw source data ingestion with source metadata.
- **Silver Layer:** Cleaned, deduplicated, and currency-normalized records.
- **Gold Layer:** Analytics-ready feature tables consumed by AI models.

---

## 6. MODULE 05 — CRM & SALES COMPLETE SPECIFICATION

Module 05 is the **commercial system of record**. Every revenue event originates here.

### 6.1 Complete Prisma Entity Schema

```prisma
// ==========================================
// MODULE 05: CRM & SALES CANONICAL SCHEMA
// ==========================================

model Customer {
  id                 String          @id @default(cuid())
  tenantId           String          // ENFORCE: tenant scoping mandatory
  externalId         String?         // HarvyX or external reference
  code               String          // Unique customer code per tenant
  name               String
  legalName          String?
  tradingName        String?
  type               CustomerType    @default(SME)
  classification     String?         // A-class, Strategic, Key-Account
  status             CustomerStatus  @default(PROSPECT)
  industryCode       String?         // ISIC / NAICS
  countryCode        String          // ISO 3166-1 alpha-2
  currencyCode       String          @default("USD")
  languageCode       String?         @default("en")
  taxId              String?
  vatNumber          String?
  website            String?
  phone              String?
  email              String?
  billingAddressId   String?
  shippingAddressId  String?
  assignedSalesRep   String?         // User.id
  assignedAccountMgr String?         // User.id
  sourceChannel      String?         // HARVYX | REFERRAL | INBOUND
  parentCustomerId   String?
  creditLimitId      String?
  priceListId        String?
  paymentTerms       String?         @default("NET30")
  notes              String?
  tags               String[]
  metaData           Json?
  createdAt          DateTime        @default(now())
  updatedAt          DateTime        @updatedAt
  createdBy          String          // User.id
  updatedBy          String?
  deletedAt          DateTime?       // Soft-delete

  contacts           Contact[]
  deals              Deal[]
  orders             SalesOrder[]
  activities         CrmActivity[]
  creditLimit        CreditLimit?
  priceList          PriceList?      @relation(fields: [priceListId], references: [id])
  tickets            SupportTicket[]
  subscriptions      Subscription[]
}

model Contact {
  id              String    @id @default(cuid())
  tenantId        String
  customerId      String
  firstName       String
  lastName        String
  title           String?
  jobTitle        String?
  department      String?
  email           String?
  phone           String?
  mobile          String?
  linkedIn        String?
  isPrimary       Boolean   @default(false)
  isDecisionMaker Boolean   @default(false)
  preferredLang   String?   @default("en")
  notes           String?
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  createdBy       String
  deletedAt       DateTime?

  customer        Customer  @relation(fields: [customerId], references: [id])
  activities      CrmActivity[]
}

model Lead {
  id                  String      @id @default(cuid())
  tenantId            String
  externalId          String?     // HarvyX import idempotency ref
  source              LeadSource  @default(WEB)
  status              LeadStatus  @default(NEW)
  firstName           String
  lastName            String
  email               String?
  phone               String?
  company             String?
  jobTitle            String?
  countryCode         String?
  industryCode        String?
  estimatedValue      Decimal?    @db.Decimal(18, 4)
  currency            String?     @default("USD")
  productInterest     String[]
  assignedTo          String?     // User.id
  score               Int?        // 0-100 AI score
  scoreModel          String?
  scoreAt             DateTime?
  qualificationNotes  String?
  disqualifyReason    String?
  convertedAt         DateTime?
  convertedCustomerId String?
  convertedDealId     String?
  lastContactedAt     DateTime?
  nextFollowUpAt      DateTime?
  tags                String[]
  metaData            Json?
  createdAt           DateTime    @default(now())
  updatedAt           DateTime    @updatedAt
  createdBy           String
  updatedBy           String?
  deletedAt           DateTime?

  activities          CrmActivity[]
}

model Deal {
  id                String      @id @default(cuid())
  tenantId          String
  customerId        String
  contactId         String?
  name              String
  stage             DealStage   @default(DISCOVERY)
  probability       Int         @default(20) // 0-100
  value             Decimal     @db.Decimal(18, 4)
  currency          String      @default("USD")
  valueLocal        Decimal?    @db.Decimal(18, 4)
  localCurrency     String?
  fxRateApplied     Decimal?    @db.Decimal(18, 6)
  assignedTo        String?     // User.id
  expectedCloseDate DateTime?
  actualCloseDate   DateTime?
  lostReason        String?
  competitorNotes   String?
  nextAction        String?
  nextActionDue     DateTime?
  forecastCategory  String?     @default("PIPELINE") // COMMIT | BEST_CASE | PIPELINE
  tags              String[]
  metaData          Json?
  createdAt         DateTime    @default(now())
  updatedAt         DateTime    @updatedAt
  createdBy         String
  updatedBy         String?
  deletedAt         DateTime?

  customer          Customer    @relation(fields: [customerId], references: [id])
  quotes            Quote[]
  orders            SalesOrder[]
  activities        CrmActivity[]
}

model Quote {
  id               String      @id @default(cuid())
  tenantId         String
  quoteNumber      String
  dealId           String
  customerId       String
  contactId        String?
  status           QuoteStatus @default(DRAFT)
  validUntil       DateTime
  currency         String      @default("USD")
  subtotal         Decimal     @db.Decimal(18, 4)
  discountAmount   Decimal     @db.Decimal(18, 4) @default(0)
  taxAmount        Decimal     @db.Decimal(18, 4) @default(0)
  totalAmount      Decimal     @db.Decimal(18, 4)
  paymentTerms     String?
  deliveryTerms    String?     // Incoterms
  notes            String?
  internalNotes    String?
  approvedBy       String?
  approvedAt       DateTime?
  rejectedBy       String?
  rejectedAt       DateTime?
  rejectionReason  String?
  convertedOrderId String?
  governanceRef    String?
  documentVaultId  String?
  createdAt        DateTime    @default(now())
  updatedAt        DateTime    @updatedAt
  createdBy        String
  updatedBy        String?
  deletedAt        DateTime?

  deal             Deal        @relation(fields: [dealId], references: [id])
  lines            QuoteLine[]
}

model QuoteLine {
  id              String    @id @default(cuid())
  quoteId         String
  lineNumber      Int
  productId       String
  sku             String
  description     String
  quantity        Decimal   @db.Decimal(18, 4)
  uom             String
  unitPrice       Decimal   @db.Decimal(18, 4)
  discount        Decimal   @db.Decimal(5, 4) @default(0)
  taxCode         String?
  taxRate         Decimal?  @db.Decimal(5, 4)
  taxAmount       Decimal   @db.Decimal(18, 4) @default(0)
  lineTotal       Decimal   @db.Decimal(18, 4)
  deliveryDate    DateTime?
  notes           String?

  quote           Quote     @relation(fields: [quoteId], references: [id])
}

model SalesOrder {
  id                     String           @id @default(cuid())
  tenantId               String
  orderNumber            String
  dealId                 String?
  quoteId                String?
  customerId             String
  contactId              String?
  status                 SalesOrderStatus @default(DRAFT)
  orderDate              DateTime         @default(now())
  requestedDelivery      DateTime?
  confirmedDelivery      DateTime?
  currency               String           @default("USD")
  subtotal               Decimal          @db.Decimal(18, 4)
  discountAmount         Decimal          @db.Decimal(18, 4) @default(0)
  taxAmount              Decimal          @db.Decimal(18, 4) @default(0)
  totalAmount            Decimal          @db.Decimal(18, 4)
  paymentTerms           String?
  deliveryTerms          String?
  deliveryAddress        Json?
  warehouseId            String?
  creditCheckPassed      Boolean?
  creditCheckAt          DateTime?
  governanceRef          String?
  inventoryReservationId String?
  invoiceId              String?
  notes                  String?
  internalNotes          String?
  createdAt              DateTime         @default(now())
  updatedAt              DateTime         @updatedAt
  createdBy              String
  updatedBy              String?
  deletedAt              DateTime?

  customer               Customer         @relation(fields: [customerId], references: [id])
  lines                  SalesOrderLine[]
}

model SalesOrderLine {
  id          String     @id @default(cuid())
  orderId     String
  lineNumber  Int
  productId   String
  sku         String
  description String
  quantity    Decimal    @db.Decimal(18, 4)
  uom         String
  unitPrice   Decimal    @db.Decimal(18, 4)
  discount    Decimal    @db.Decimal(5, 4) @default(0)
  taxCode     String?
  taxRate     Decimal?   @db.Decimal(5, 4)
  taxAmount   Decimal    @db.Decimal(18, 4) @default(0)
  lineTotal   Decimal    @db.Decimal(18, 4)
  reservedQty Decimal?   @db.Decimal(18, 4)
  shippedQty  Decimal?   @db.Decimal(18, 4)
  invoicedQty Decimal?   @db.Decimal(18, 4)
  notes       String?

  order       SalesOrder @relation(fields: [orderId], references: [id])
}

model CrmActivity {
  id           String         @id @default(cuid())
  tenantId     String
  type         ActivityType   @default(NOTE)
  subject      String
  body         String?
  status       ActivityStatus @default(COMPLETED)
  dueAt        DateTime?
  completedAt  DateTime?
  durationMins Int?
  direction    String?
  outcome      String?
  linkedType   String         // LEAD | CUSTOMER | DEAL | QUOTE | ORDER
  linkedId     String
  customerId   String?
  contactId    String?
  leadId       String?
  dealId       String?
  assignedTo   String
  createdBy    String
  createdAt    DateTime       @default(now())
  updatedAt    DateTime       @updatedAt

  customer     Customer?      @relation(fields: [customerId], references: [id])
  contact      Contact?       @relation(fields: [contactId], references: [id])
  lead         Lead?          @relation(fields: [leadId], references: [id])
  deal         Deal?          @relation(fields: [dealId], references: [id])
}

model CreditLimit {
  id              String    @id @default(cuid())
  tenantId        String
  customerId      String    @unique
  approvedLimit   Decimal   @db.Decimal(18, 4)
  currency        String    @default("USD")
  usedAmount      Decimal   @db.Decimal(18, 4) @default(0)
  availableAmount Decimal   @db.Decimal(18, 4)
  basis           String?
  reviewDate      DateTime?
  approvedBy      String
  approvedAt      DateTime  @default(now())
  notes           String?
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt

  customer        Customer  @relation(fields: [customerId], references: [id])
}

model PriceList {
  id        String          @id @default(cuid())
  tenantId  String
  name      String
  currency  String          @default("USD")
  type      PriceListType   @default(STANDARD)
  validFrom DateTime        @default(now())
  validTo   DateTime?
  isDefault Boolean         @default(false)
  createdAt DateTime        @default(now())
  updatedAt DateTime        @updatedAt
  createdBy String

  entries   PriceListEntry[]
  customers Customer[]
}

model PriceListEntry {
  id          String    @id @default(cuid())
  priceListId String
  productId   String
  sku         String
  minQty      Decimal   @db.Decimal(18, 4) @default(1)
  unitPrice   Decimal   @db.Decimal(18, 4)
  discount    Decimal   @db.Decimal(5, 4) @default(0)

  priceList   PriceList @relation(fields: [priceListId], references: [id])
}

model Subscription {
  id            String    @id @default(cuid())
  tenantId      String
  customerId    String
  planId        String
  status        String    @default("ACTIVE")
  billingCycle  String    @default("MONTHLY")
  nextBillingAt DateTime?
  startDate     DateTime  @default(now())
  endDate       DateTime?
  mrr           Decimal?  @db.Decimal(18, 4)
  currency      String    @default("USD")
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt

  customer      Customer  @relation(fields: [customerId], references: [id])
}

model SupportTicket {
  id              String    @id @default(cuid())
  tenantId        String
  ticketNumber    String
  customerId      String
  contactId       String?
  orderId         String?
  type            String    @default("INQUIRY")
  priority        String    @default("MEDIUM")
  status          String    @default("OPEN")
  subject         String
  description     String
  assignedTo      String?
  firstResponseAt DateTime?
  resolvedAt      DateTime?
  closedAt        DateTime?
  slaId           String?
  slaBreach       Boolean   @default(false)
  resolution      String?
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt

  customer        Customer  @relation(fields: [customerId], references: [id])
}

enum CustomerType { ENTERPRISE SME DISTRIBUTOR CONSUMER GOVERNMENT }
enum CustomerStatus { PROSPECT ACTIVE ON_HOLD INACTIVE BLACKLISTED }
enum LeadSource { HARVYX WEB REFERRAL TRADE_SHOW COLD_OUTREACH INBOUND_CALL OTHER }
enum LeadStatus { NEW CONTACTED QUALIFIED DISQUALIFIED CONVERTED }
enum DealStage { DISCOVERY QUALIFIED PROPOSAL NEGOTIATION CLOSED_WON CLOSED_LOST }
enum QuoteStatus { DRAFT SUBMITTED APPROVED REJECTED EXPIRED CONVERTED }
enum SalesOrderStatus { DRAFT CONFIRMED CREDIT_HOLD IN_FULFILLMENT SHIPPED DELIVERED INVOICED CANCELLED }
enum ActivityType { CALL EMAIL MEETING DEMO NOTE TASK WHATSAPP }
enum ActivityStatus { PLANNED COMPLETED CANCELLED }
enum PriceListType { STANDARD CUSTOMER_SPECIFIC VOLUME PROMOTIONAL }
```

---

### 6.2 Key Workflow Execution Specifications (Manhattan Level)

#### A. Capture Lead (`POST /api/crm/leads`)
- **Validation:** `firstName` and `lastName` required. `email` format checked. `externalId` checked for idempotency.
- **Business Rule:** Unify all incoming lead creation on Module 05 API. Deprecate duplicate demo endpoints.
- **AI Action:** Trigger async Groq AI lead scoring. Store score in `score`, `scoreModel`, `scoreAt`. Fallback to heuristic scoring if Groq is down.
- **Audit & Event:** Write `Lead` and `AuditLog`. Emit `lead.created` event.

#### B. Convert Lead (`POST /api/crm/leads/:id/convert`)
- **Pre-condition:** Lead status MUST be `QUALIFIED`. Cannot convert an already converted lead.
- **Neural Governance:** HIGH risk write. Evaluate Legal (entity check), Contract, Security (actor permissions), and Compliance (AML/sanctions screening).
- **Atomic Transaction:**
  1. Create or link `Customer` record.
  2. Create `Contact` record.
  3. Optionally create `Deal` record.
  4. Update `Lead.status = CONVERTED` and link IDs.
  5. Emit `customer.created`, `deal.created`, and `lead.converted` events.

#### C. Create CPQ Quote (`POST /api/crm/deals/:id/quotes`)
- **Pre-condition:** Deal exists in valid tenant. Lines pull active SKUs from Product Catalogue.
- **Price Resolution:** Resolve price from `PriceList` in order: Customer-Specific → Volume → Promotional → Standard.
- **Tax & FX Calls:** Synchronous call to Tax Engine (Module 17) and FX Engine (Module 18). If Tax Engine fails, block quote creation (HTTP 503). Do not estimate tax.
- **Neural Governance:** Validate sales rep discount authority. Require manager approval if discount exceeds tenant threshold.

#### D. Confirm Sales Order (`POST /api/crm/quotes/:id/convert-to-order`)
- **Pre-condition:** Quote status MUST be `APPROVED`.
- **Credit Check:** Query `CreditLimit` service. If `usedAmount + orderTotal > approvedLimit`, set order status to `CREDIT_HOLD`.
- **Idempotency:** Validate `idempotencyKey`. Return existing order if duplicate submission occurs.
- **Events:** Emit `sales.order.confirmed`. Inventory subscribes and issues `inventory.reservation.requested`.

---

## 7. DOMAIN API ROUTE CONTRACTS

All API endpoints reside under `/api/crm`. Mandatory Header: `Authorization: Bearer <jwt>`.

```text
METHOD  PATH                                    PERMISSION          STAGE STATUS
────────────────────────────────────────────────────────────────────────────────
POST    /api/crm/leads                          crm:lead:create     S3 -> S4
GET     /api/crm/leads                          crm:lead:read       S3 -> S4
GET     /api/crm/leads/:id                      crm:lead:read       S3 -> S4
PATCH   /api/crm/leads/:id                      crm:lead:update     S3 -> S4
POST    /api/crm/leads/:id/qualify              crm:lead:qualify    S2 -> S4
POST    /api/crm/leads/:id/convert              crm:lead:convert    S2 -> S4
DELETE  /api/crm/leads/:id                      crm:lead:delete     S3 (soft)

POST    /api/crm/customers                      crm:cust:create     S3 -> S4
GET     /api/crm/customers                      crm:cust:read       S3 -> S4
GET     /api/crm/customers/:id                  crm:cust:read       S3 -> S4
GET     /api/crm/customers/:id/360              crm:cust:read       S3 -> S4
PATCH   /api/crm/customers/:id                  crm:cust:update     S3 -> S4

POST    /api/crm/deals                          crm:deal:create     S3 -> S4
GET     /api/crm/deals                          crm:deal:read       S3 -> S4
GET     /api/crm/deals/:id                      crm:deal:read       S3 -> S4
PATCH   /api/crm/deals/:id                      crm:deal:update     S3 -> S4

POST    /api/crm/deals/:id/quotes               crm:quote:create    S1 -> S4
POST    /api/crm/quotes/:id/approve             crm:quote:approve   S1 -> S4
POST    /api/crm/quotes/:id/convert-to-order    crm:order:create    S1 -> S4

POST    /api/crm/orders                         crm:order:create    S1 -> S4
GET     /api/crm/orders/:id                     crm:order:read      S1 -> S4
POST    /api/crm/orders/:id/release             crm:order:release   S1 -> S4
POST    /api/crm/orders/:id/request-invoice     crm:order:invoice   S1 -> S4
```

---

## 8. MASTER BUILD ROADMAP (10-PHASE EXECUTION)

```text
               [PHASE 0: AUDIT & CLEAN MOCK DATA]
                                 │
              [PHASE 1: PLATFORM FOUNDATION & IDENTITY]
                                 │
              [PHASE 2: COMMERCIAL SPINE (CRM → CPQ → ORDER)]
                                 │
              [PHASE 3: PROCUREMENT & SUPPLY (PR → PO → WMS)]
                                 │
              [PHASE 4: OPERATIONS & TRADE (TMS → HARVICSTRADE)]
                                 │
              [PHASE 5: FINANCIAL ENGINE (HPAY → LEDGER → TAX)]
                                 │
              [PHASE 6: INTELLIGENCE & SOUL (OCEAN → GOVERNANCE)]
                                 │
              [PHASE 7: HARVICSTRADE END-TO-END VERTICAL SLICE]
                                 │
              [PHASE 8: HARVICS UNIVERSE PORTALS]
                                 │
              [PHASE 9: SELECTIVE HIGH-SCALE OPTIMIZATION]
```

---

## 9. WHAT CURSOR MUST NOT DO

```text
✗  DO NOT use GenericModuleRecord (/api/m/:id) for Lead, Customer, Deal, Quote, or Order data.
✗  DO NOT render mock KPI numbers (847 accounts, $4.82M, etc.) anywhere in the UI.
✗  DO NOT accept tenantId from the client request body. Always derive from JWT claims.
✗  DO NOT call the Tax Engine and silently use a default if it fails. Quote creation MUST block.
✗  DO NOT write actorId = null or actorRole = null to the audit log.
✗  DO NOT hard-delete any Customer, Lead, Deal, Quote, or Order record. Soft-delete only.
```

---

## 10. CURSOR EXECUTION COMMANDS

### Command 1: Execute Phase 0 — Audit & Unify CRM
```markdown
Read MASTER_CURSOR_CONSTITUTION.md at repository root before touching any files.

TASK: Execute Phase 0 — CRM Lead Unification & Mock Data Cleanup

1. Inspect src/app/os and backend/src/modules/crm.
2. Deprecate duplicate lead controllers (/api/crm/leads vs Wave 8). Unify on the canonical Lead Prisma schema.
3. Remove hardcoded mock KPI stats ($4.82M / 847 accounts) from /os/crm/legacy and replace with dynamic DB aggregations or EmptyState UI.
4. Enforce mandatory tenantId extraction from Bearer JWT context across all Express routes.
5. Run typecheck and lint to verify zero regressions.
```

### Command 2: Execute Phase 2 — Quote-to-Cash Thin Slice
```markdown
Read MASTER_CURSOR_CONSTITUTION.md at repository root.

TASK: Build Phase 2 — CPQ Quote to SalesOrder Conversion Pipeline

1. Ensure Quote, QuoteLine, SalesOrder, and SalesOrderLine Prisma models are migrated.
2. Implement POST /api/crm/deals/:id/quotes with synchronous Tax Engine (Module 17) integration.
3. Implement POST /api/crm/quotes/:id/convert-to-order with CreditLimit check and idempotency key validation.
4. Wire server-side Neural Governance evaluation before order confirmation.
5. Write integration tests validating the complete Lead -> Deal -> Quote -> SalesOrder path.
```
