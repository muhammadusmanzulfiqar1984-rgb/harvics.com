# DOMAIN MASTER INDEX

This is the canonical development index.

## Core OS / Enterprise

| Domain | Owns | Primary value stream |
|---|---|---|
| Finance | Accounting truth | Record-to-Report |
| Treasury | Liquidity | Cash-to-Cash |
| Procurement | Purchase commitments | Source-to-Pay |
| Order Management | Confirmed demand / fulfilment | Order-to-Cash |
| CRM/Sales | Relationship / opportunity / quote | Lead-to-Cash |
| Marketing | Demand generation | Campaign-to-Revenue |
| Trade Promotion | Channel economics | Promotion-to-Revenue |
| Manufacturing | Production execution | Plan-to-Produce |
| Supply Planning | Demand/supply balance | Forecast-to-Plan |
| Inventory/WMS | Physical stock | Inventory-to-Deliver |
| Quality | Quality/release | Inspect-to-Release |
| Logistics/TMS | Movement | Ship-to-Deliver |
| Shipping/Trade | Global trade execution | Trade-to-Settlement |
| EAM | Physical assets | Acquire-to-Dispose |
| PLM | Product lifecycle | Idea-to-Retirement |
| PIM | Commercial product content | Product-to-Market |
| R&D | Innovation | Research-to-Release |
| Projects | Delivery portfolio | Project-to-Cash |
| Service | Support/field work | Service-to-Resolve |
| HR/Payroll | Workforce | Hire-to-Retire |
| Legal/Compliance | Legal/control state | Contract-to-Obligation |
| ERM | Enterprise risk | Risk-to-Control |
| ESG | Sustainability | Measure-to-Report |

## Shared Platform

Identity, MDM, Localisation, Geo, Data Ocean, AI, Governance, Audit, Documents, Notifications, Integration/API Fabric, Search, Workflow, Observability.

## Financial Infrastructure

HPay, Ledger, Payments, Settlement, Risk/KYC/KYB.

## Universe

FunFeed, Mall, Trade Floor, Playroom, Experts Hub, Jobs + Travel, Crypto Lite, Harvicoins, HPay Wallet, Circle.

## Intelligence

HarvyX, Harvey, Harvoice, Executive Intelligence, Soul/Globalisation.
