# ARCHITECTURE RULES

1. Modular monolith first.
2. Domains own their persistence.
3. Shared primitives are canonical.
4. Cross-domain writes use application contracts.
5. Events describe completed facts.
6. AI is not transactional truth.
7. Data Ocean is not transactional truth.
8. Finance uses immutable double-entry accounting.
9. HPay is not a bank.
10. Governance is server-side.
11. Tenant isolation is mandatory.
12. Secrets never enter client code.
13. Provider adapters hide provider-specific contracts.
14. No fake data in production UI.
15. No route is considered complete without its backend workflow.
16. No generic CRUD substitute for a business process.
17. Do not split services prematurely.
18. Do not claim current implementation from target architecture.
19. Do not invent source-unsupported legal/regulatory facts.
20. Prefer a complete vertical slice over broad scaffolding.
