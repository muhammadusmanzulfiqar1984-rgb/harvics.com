# API / EVENT CATALOGUE

## Representative domain APIs

### CRM
GET /customers
POST /customers
GET /customers/:id
POST /leads
POST /opportunities
POST /quotes
POST /quotes/:id/approve

### Procurement
GET /purchase-requests
POST /purchase-requests
POST /rfqs
POST /supplier-quotes
POST /purchase-orders
POST /purchase-orders/:id/approve
POST /goods-receipts

### Orders
GET /orders
POST /orders
POST /orders/:id/confirm
POST /orders/:id/allocate
POST /orders/:id/cancel

### Inventory
GET /inventory
POST /inventory/reservations
POST /inventory/movements
POST /inventory/transfers

### Finance
POST /invoices
POST /payments
POST /journals
POST /periods/:id/close

### HPay
POST /payment-intents
POST /payments
POST /refunds
POST /payouts
POST /webhooks

### Trade
POST /trade/rfqs
POST /trade/suppliers
POST /trade/compliance/checks
POST /trade/shipments
POST /trade/settlements

These are canonical resource families, not permission to create blind CRUD. Final contracts must match repository conventions.

## Event catalogue

purchase.requested
purchase.request.approved
rfq.issued
supplier.quote.received
purchase.order.created
purchase.order.approved
goods.receipt.created
quality.inspection.completed
batch.released
sales.order.confirmed
sales.order.allocated
shipment.dispatched
delivery.completed
invoice.issued
payment.authorized
payment.settled
ledger.posted
contract.signed
kyc.approved
kyb.approved
governance.blocked
governance.approved
