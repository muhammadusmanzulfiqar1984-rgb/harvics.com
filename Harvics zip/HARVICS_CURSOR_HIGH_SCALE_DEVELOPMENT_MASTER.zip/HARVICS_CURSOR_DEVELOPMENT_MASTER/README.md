# HARVICS — CURSOR HIGH-SCALE DEVELOPMENT PACKAGE

## Start here

1. `00-master/HARVICS_CURSOR_MASTER_DEVELOPMENT_SPEC.md`
2. `00-master/SOURCE_DISCIPLINE.md`
3. `01-system/DOMAIN_MASTER_INDEX.md`
4. `01-system/ARCHITECTURE_RULES.md`
5. relevant domain file
6. value stream
7. API/event contract
8. testing/build protocol

## What this package fixes

This is not merely a list of the original 32 modules.

It retains the source architecture and adds the missing enterprise capabilities as explicitly labelled architectural expansions:

- PLM
- EAM
- S&OP / Supply Planning
- Order Management
- Service / Field Operations
- MDM
- ERM
- ESG
- R&D / Innovation
- Retail/POS
- Trade Promotion / Revenue Management
- PIM
- Integration/API Fabric

## Important distinction

```text
SOURCE PRODUCT TAXONOMY
32 modules

PRODUCTION NORMALISATION
20 OS domains + shared core

REGISTRY
71 catalogue modules

EXPANDED ENTERPRISE CAPABILITY MODEL
broader capability architecture
```

Do not turn the expanded capability model into an arbitrary number of microservices.

## Build philosophy

The system is built as a coherent organism.

Commercial proof first.
Financial integrity always.
AI controlled.
Governance enforced.
Data owned.
Events explicit.
UI truthful.
Production status evidenced.
