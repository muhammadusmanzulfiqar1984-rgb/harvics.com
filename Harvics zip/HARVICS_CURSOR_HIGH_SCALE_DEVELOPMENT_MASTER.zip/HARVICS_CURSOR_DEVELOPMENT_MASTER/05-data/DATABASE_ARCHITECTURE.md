# DATABASE ARCHITECTURE

## Principles

- PostgreSQL as transactional source.
- Prisma as schema/application access layer where current stack requires it.
- UUID identifiers.
- UTC timestamps.
- BIGINT monetary minor units.
- tenant scoping.
- explicit status/state.
- audit metadata.
- indexes based on actual query patterns.

## Schema organisation

Logical namespaces may be represented through domain prefixes/modules if PostgreSQL schema separation is not adopted.

Example:

```text
identity_*
crm_*
sales_*
procurement_*
inventory_*
manufacturing_*
quality_*
logistics_*
finance_*
hpay_*
trade_*
people_*
legal_*
risk_*
platform_*
universe_*
```

The exact physical Prisma organisation must follow the repository.

## No duplication rule

Customer, supplier, product, location and financial-account identity should reference canonical master records.

## Migration rule

Every schema change:
- migration
- backward compatibility review
- seed impact
- API impact
- event impact
- rollback consideration
- tests
