# CURSOR BUILD PROTOCOL

## Before coding

1. Read the master specification.
2. Read the relevant domain file.
3. Inspect existing repository.
4. Identify current implementation status.
5. Identify existing Prisma models.
6. Identify existing APIs.
7. Identify existing UI.
8. Identify conflicts.
9. Plan smallest complete vertical slice.

## During coding

- Preserve existing working behaviour.
- Avoid duplicate entities.
- Use existing design system.
- Use typed APIs.
- Add migrations.
- Add tests.
- Add audit.
- Add governance.
- Add events where integration requires them.

## After coding

Run:

```text
typecheck
lint
unit tests
integration tests
build
migration validation
security checks
```

Then verify:

```text
UI
→ API
→ DB
→ Event
→ Audit
```

## Do not

- fabricate data
- fake completion
- silently rewrite architecture
- add arbitrary dependencies
- split services unnecessarily
- expose secrets
- bypass governance
- bypass RBAC
- claim production status without evidence
