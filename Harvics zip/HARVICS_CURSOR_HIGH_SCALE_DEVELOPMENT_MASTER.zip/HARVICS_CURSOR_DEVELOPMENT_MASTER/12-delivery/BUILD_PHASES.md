# BUILD PHASES

## Phase 0 — Architecture integrity
Repository audit, schema audit, route audit, module registry, status map.

## Phase 1 — Platform foundation
Identity, tenant, RBAC, audit, MDM, documents, notifications, localisation, observability.

## Phase 2 — Commercial spine
CRM, product, PIM, pricing, quote, contract, order management.

## Phase 3 — Procurement and fulfilment
Procurement, inventory, quality, supply planning, manufacturing.

## Phase 4 — Delivery
Logistics, trade, EAM, service.

## Phase 5 — Finance
Ledger, Finance, Treasury, Tax, FX, HPay.

## Phase 6 — Intelligence
Data Ocean, AI, Harvey, Harvoice, Soul, Governance.

## Phase 7 — HarvicsTrade
Complete trade vertical slice.

## Phase 8 — Universe
Release Universe modules progressively after core commercial/financial reliability.

## Phase 9 — Scale
Selective service extraction based on measured bottlenecks.
