# PLATFORM SERVICES

## Identity
Authentication, sessions, MFA, SSO, user lifecycle.

## Tenant
Organisation, business unit, tenant boundaries.

## RBAC
Role, permission, policy.

## MDM
Golden records and stewardship.

## Localisation
Country, currency, language, timezone, tax context.

## Geo
Global → continent → region → country → city → district → area → location.

## Audit
Immutable material action trail.

## Documents
Object storage, versioning, access, retention.

## Notifications
Email, SMS, WhatsApp, push, in-app.

## Integration/API Fabric
API gateway, webhooks, event adapters, provider abstractions.

## Search
Cross-domain indexed search with tenant filters.

## Workflow
Long-running jobs, retries, schedules, approvals.

## Observability
Logs, metrics, traces, alerts, health.
