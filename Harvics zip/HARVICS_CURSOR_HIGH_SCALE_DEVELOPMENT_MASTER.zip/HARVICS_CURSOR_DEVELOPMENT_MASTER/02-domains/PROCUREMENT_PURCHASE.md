# PROCUREMENT / PURCHASE — IMPLEMENTATION SPEC

## Bounded context
Procurement owns purchase demand through supplier commitment and receipt. Finance owns payment/accounting truth.

## Core aggregates
- PurchaseRequest
- RFQ
- SupplierQuote
- PurchaseOrder
- GoodsReceipt
- PurchaseReturn
- SupplierInvoiceMatch

## Key relationships
```text
PurchaseRequest 1→N PurchaseRequestLine
RFQ 1→N RFQLine
RFQ 1→N SupplierQuote
SupplierQuote 1→N SupplierQuoteLine
PurchaseOrder 1→N PurchaseOrderLine
PurchaseOrder 1→N GoodsReceipt
SupplierInvoice 1→N MatchResult
```

## State
PurchaseRequest:
```text
DRAFT → SUBMITTED → APPROVED → SOURCING → ORDERED → CLOSED
                 ↘ REJECTED
```

PurchaseOrder:
```text
DRAFT → PENDING_APPROVAL → APPROVED → SENT → ACKNOWLEDGED
→ PARTIALLY_RECEIVED → RECEIVED → CLOSED
```

## Commands
- createPurchaseRequest
- submitPurchaseRequest
- approvePurchaseRequest
- issueRFQ
- recordSupplierQuote
- compareSupplierQuotes
- selectSupplier
- createPurchaseOrder
- approvePurchaseOrder
- sendPurchaseOrder
- createGoodsReceipt
- createPurchaseReturn
- matchSupplierInvoice

## Events
- purchase.requested
- purchase.request.approved
- rfq.issued
- supplier.quote.received
- supplier.selected
- purchase.order.created
- purchase.order.approved
- purchase.order.sent
- goods.receipt.created
- purchase.invoice.matched

## Governance
- Budget
- Supplier compliance
- Contract
- Security
- Legal where required

## AI
- quote comparison
- supplier score
- price anomaly
- savings opportunity
- reorder recommendation

AI output is advisory unless a governed action explicitly permits automation.

## UI
- Procurement Dashboard
- Purchase Requests
- RFQs
- Supplier Quotes
- Quote Comparison
- Purchase Orders
- Goods Receipts
- Supplier Invoices
- Spend Analytics
- Supplier Performance

## Critical acceptance test
A real purchase must be traceable from request to PO to receipt to invoice match to payment request to ledger.
