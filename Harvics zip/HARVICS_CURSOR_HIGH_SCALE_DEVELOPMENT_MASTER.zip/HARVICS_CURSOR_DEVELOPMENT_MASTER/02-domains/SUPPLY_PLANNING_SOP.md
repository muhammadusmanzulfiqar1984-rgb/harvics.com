# SUPPLY PLANNING / S&OP

## Purpose
Balance demand, supply, inventory, production and procurement.

## Inputs
- historical orders
- open pipeline
- promotions
- seasonality
- inventory
- supplier lead time
- production capacity
- external signals

## Outputs
- forecast
- supply plan
- production plan
- purchase recommendation
- inventory target
- exception

## Cycle
```text
Forecast
→ Demand Review
→ Supply Review
→ Capacity Review
→ Scenario
→ Executive S&OP
→ Approved Plan
→ Execution
```

AI recommendations must expose confidence and source context.
