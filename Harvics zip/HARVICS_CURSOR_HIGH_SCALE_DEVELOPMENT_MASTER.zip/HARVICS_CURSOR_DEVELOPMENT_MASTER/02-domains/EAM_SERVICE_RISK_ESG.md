# EAM + SERVICE + ERM + ESG

## EAM
Asset lifecycle, maintenance, work orders, warranties, spare parts, depreciation integration.

## Service
Cases, SLA, service contract, technician, work order, parts, resolution, warranty.

## ERM
Risk register, taxonomy, appetite, controls, mitigation, KRIs, owners.

## ESG
Emissions, energy, water, waste, supplier ESG, targets, evidence, reporting.

These are distinct domains. Do not put all four into a generic Administration module.
