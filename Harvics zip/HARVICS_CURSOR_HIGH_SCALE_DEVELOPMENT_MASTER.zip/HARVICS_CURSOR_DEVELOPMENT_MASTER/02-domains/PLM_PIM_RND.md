# PLM + PIM + R&D

## Boundary

R&D:
creates knowledge, trials and concepts.

PLM:
owns engineering/product lifecycle truth.

PIM:
owns channel-facing product content.

Manufacturing:
owns production execution.

## Lifecycle

```text
Idea
→ Research
→ Concept
→ Specification
→ Prototype
→ Test
→ Revision
→ Approval
→ Production Release
→ Commercial Publication
→ Change
→ End-of-Life
```

## PLM entities
ProductConcept
ProductSpecification
ProductRevision
Formula
PackagingSpecification
EngineeringChangeOrder
ProductLifecycle

## PIM entities
ProductContent
ProductAttribute
ProductMedia
ProductTranslation
ChannelPublication
CountryClaim
ProductIdentifier

## R&D entities
ResearchProject
Trial
Sample
Experiment
TestResult
InnovationIdea

## Critical rule
A product cannot be commercially published from an unapproved lifecycle revision.
