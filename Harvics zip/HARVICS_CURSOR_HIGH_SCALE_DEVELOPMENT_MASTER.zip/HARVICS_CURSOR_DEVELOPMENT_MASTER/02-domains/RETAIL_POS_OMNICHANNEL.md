# RETAIL / POS / OMNICHANNEL

Status: FUTURE CAPABILITY / NOT A CURRENT CORE BUILD REQUIREMENT.

Capabilities:
- store
- POS
- register
- retail order
- omnichannel inventory
- promotion
- click-and-collect
- return
- store operations
- channel pricing

Integrate with:
CRM, Inventory, Order Management, Finance, Marketing, Harvics Mall.

Do not build this before the B2B commercial spine is operational unless a real customer requirement demands it.
