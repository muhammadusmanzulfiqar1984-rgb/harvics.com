# ORDER MANAGEMENT — IMPLEMENTATION SPEC

## Boundary

CRM owns lead/opportunity/quote.
Order Management owns confirmed demand and fulfilment orchestration.
Inventory owns stock.
Manufacturing owns production.
Logistics owns movement.
Finance owns invoice/accounting truth.

## Aggregate
SalesOrder

## State
```text
DRAFT
→ CONFIRMED
→ CREDIT_HOLD / ALLOCATION_HOLD
→ ALLOCATED
→ PARTIALLY_FULFILLED
→ FULFILLED
→ INVOICED
→ CLOSED
```

Exceptions:
CANCELLED, BACKORDERED, DISPUTED.

## Core capabilities
- order capture
- validation
- credit hold
- ATP
- allocation
- split fulfilment
- backorder
- cancellation
- change
- fulfilment orchestration

## Events
sales.order.confirmed
sales.order.allocated
sales.order.backordered
sales.order.fulfilled
sales.order.cancelled
sales.order.invoicing.requested

## Critical test
One order may be fulfilled from multiple warehouses or production batches without corrupting quantity, reservation or financial state.
