# HARVICS — CURSOR MASTER DEVELOPMENT SPECIFICATION
## High-Scale Implementation Architecture — V1

> This is the authoritative development specification for Cursor.
> It is a construction document, not a pitch document.

---

# 0. EXECUTIVE DIRECTIVE

Build Harvics as an **AI-native global B2B trade and operating infrastructure platform**, not as a collection of unrelated CRUD modules.

The system must be constructed around:

1. **Commercial value streams**
2. **Bounded business domains**
3. **Shared platform services**
4. **A single governed data model**
5. **Event-driven integration where useful**
6. **AI as a controlled decision layer**
7. **HPay as a governed financial rail**
8. **HarvicsTrade as the commercial wedge**
9. **Data Ocean as the intelligence substrate**
10. **Neural Governance as the control plane**

### Critical architecture rule

Do not build 60+ modules independently.

Build the **system graph**.

The system must make these chains executable:

```text
LEAD
→ OPPORTUNITY
→ QUOTE
→ CONTRACT
→ ORDER
→ CREDIT
→ INVENTORY / PRODUCTION
→ SHIPMENT
→ DELIVERY
→ INVOICE
→ PAYMENT
→ LEDGER
→ DATA
→ AI
→ NEXT DECISION
```

and:

```text
PURCHASE REQUEST
→ APPROVAL
→ RFQ
→ SUPPLIER QUOTES
→ COMPARISON
→ PURCHASE ORDER
→ GOODS RECEIPT
→ QUALITY
→ SUPPLIER INVOICE
→ 3-WAY MATCH
→ GOVERNANCE
→ PAYMENT
→ LEDGER
```

---

# 1. SOURCE AUTHORITY AND CLASSIFICATION

The architecture has multiple source layers. Do not collapse them.

## 1.1 Source-defined Harvics product taxonomy

The source architecture defines:

- **22 OS modules**
- **10 Universe modules**
- **32 product modules total**

## 1.2 Production-normalised architecture

The production blueprint normalises implementation around:

- business domains
- shared core services
- modular monolith first
- evented integration second
- selective extraction later

## 1.3 Current registry

The Board Briefing identifies:

- **71 named registry modules**
- 15 bands
- the 71-module registry as catalogue/navigation/scaffold
- not 71 independent production ERP products

Therefore:

```text
32 PRODUCT MODULES
≠
20 PRODUCTION DOMAINS
≠
71 REGISTRY MODULES
```

All three are retained.

## 1.4 Current implementation truth

The current implementation evidence must be treated separately from target architecture.

The Board Briefing indicates CRM is the clearest current commercial system of record and that the generic module factory is scaffolding.

Cursor must never infer:

```text
route exists
=
module is production
```

or:

```text
CRUD exists
=
business domain is complete
```

---

# 2. ARCHITECTURAL PRINCIPLES

## 2.1 Modular monolith first

Preferred implementation:

```text
Next.js / TypeScript
        ↓
Application layer
        ↓
Domain modules
        ↓
Prisma
        ↓
PostgreSQL
```

Use asynchronous events and background jobs where they create real value.

Extract services only when there is a proven operational reason.

## 2.2 Domain ownership

Each domain owns:

- entities
- invariants
- application services
- repositories
- commands
- queries
- policies
- events
- tests

No domain may directly modify another domain's private database tables.

## 2.3 Shared primitives

Shared platform primitives include:

- Identity
- Tenant
- Organisation
- User
- Role
- Permission
- Party
- Product
- Location
- Document
- Currency
- Tax
- FX
- Audit
- Notification
- Workflow
- Search
- Integration
- Governance

Do not duplicate these in every domain.

## 2.4 Transactional truth

AI, Data Ocean and BI are **not** transactional systems of record.

The authoritative state remains in the owning domain.

## 2.5 Financial truth

Financial mutations must use:

- integer smallest currency units
- immutable double-entry ledger
- idempotency
- reconciliation
- explicit currency
- UTC timestamps
- audit

Never use floating point for monetary accounting.

---

# 3. SYSTEM CONTEXT

```mermaid
flowchart TB
    USER[Users / Operators / Executives]
    CUSTOMER[Customers / Buyers]
    SUPPLIER[Suppliers]
    PARTNER[Partners / Carriers / PSPs]

    UX[Harvics Experience Layer]
    IAM[Identity / Tenant / RBAC]
    OS[Harvics OS Domains]
    TRADE[HarvicsTrade]
    HPAY[HPay]
    UNI[Harvics Universe]
    SOUL[Soul / Globalisation]
    OCEAN[Data Ocean]
    AI[AI / Harvey / Harvoice]
    GOV[Neural Governance]
    CORE[Shared Core]
    EXT[External Systems]

    USER --> UX
    CUSTOMER --> TRADE
    SUPPLIER --> TRADE
    PARTNER --> EXT

    UX --> IAM
    UX --> OS
    UX --> TRADE
    UX --> HPAY
    UX --> UNI

    OS --> CORE
    TRADE --> OS
    TRADE --> HPAY
    OS --> HPAY

    SOUL --> OCEAN
    OCEAN --> AI
    AI --> OS
    AI --> TRADE
    AI --> UNI

    GOV --> OS
    GOV --> TRADE
    GOV --> HPAY

    CORE --> EXT
    HPAY --> EXT
```

---

# 4. CANONICAL DOMAIN MAP

## 4.1 Enterprise domains

1. Finance
2. Treasury
3. Procurement / Purchase
4. Order Management
5. CRM / Sales
6. Marketing
7. Trade Promotion / Revenue Management
8. Manufacturing
9. Supply Planning / S&OP
10. Inventory / WMS
11. Quality
12. Logistics / TMS
13. Shipping / Trade
14. Enterprise Asset Management
15. Product Lifecycle Management
16. Product Information Management
17. R&D / Innovation
18. Projects
19. Service / Field Operations
20. HR / Payroll
21. Legal / Compliance
22. Enterprise Risk Management
23. Sustainability / ESG

## 4.2 Platform domains

24. Identity / IAM
25. Master Data Management
26. Localisation
27. Geo
28. Data Ocean
29. AI Engine
30. Neural Governance
31. Audit
32. Document Vault
33. Notifications
34. Integration / API Fabric
35. Search
36. Workflow / Automation
37. Observability / System Health

## 4.3 Financial infrastructure

38. HPay
39. Ledger
40. Payments
41. Settlement
42. Risk / KYC / KYB

## 4.4 HarvicsTrade

45. Product Discovery
46. RFQ
47. Supplier Sourcing
48. Verification
49. Compliance
50. Trade Finance
51. Logistics
52. Settlement

## 4.5 Universe

53. FunFeed
54. Harvics Mall
55. Trade Floor
56. Playroom
57. Experts Hub
58. Jobs + Travel
59. Crypto Lite
60. Harvicoins
61. HPay Fiat Wallet
62. Circle

## 4.6 Intelligence / experience

63. HarvyX / Brand Engine
64. Harvey
65. Harvoice
66. Executive Intelligence
67. Globalisation / Soul

The numbers above are capability identifiers, not a replacement for the original 32-module taxonomy.

---

# 5. THE COMMERCIAL WEDGE

Harvics should enter the market through:

## HarvicsTrade

```text
Product Discovery
→ RFQ
→ Supplier Sourcing
→ Verification
→ Compliance
→ Commercial Negotiation
→ Trade Finance
→ Logistics
→ Settlement
```

This creates the data flywheel:

```text
TRADE
 ↓
CRM
 ↓
ORDERS
 ↓
LOGISTICS
 ↓
FINANCE
 ↓
PAYMENTS
 ↓
DATA OCEAN
 ↓
AI
 ↓
BETTER TRADE
```

This is the core strategic architecture.

---

# 6. VALUE STREAMS

The following must be implemented as first-class cross-domain workflows.

## 6.1 Lead-to-Cash

```text
Lead
→ Qualification
→ Opportunity
→ Quote / CPQ
→ Contract
→ Sales Order
→ Credit Check
→ Allocation
→ Fulfilment
→ Shipment
→ POD
→ Invoice
→ Payment
→ Ledger
→ Settlement
```

## 6.2 Source-to-Pay

```text
Demand
→ Purchase Request
→ Approval
→ RFQ
→ Supplier Quotes
→ Comparison
→ Vendor Approval
→ PO
→ Goods Receipt
→ Quality
→ Supplier Invoice
→ 3-Way Match
→ Governance
→ Payment
→ Ledger
```

## 6.3 Forecast-to-Plan

```text
Historical Demand
→ External Signals
→ Forecast
→ Demand Review
→ Supply Plan
→ Capacity
→ Inventory
→ Procurement / Production
→ Exception Management
```

## 6.4 Plan-to-Produce

```text
Demand
→ MRP
→ Material Requirement
→ Capacity
→ Production Order
→ Work Centre
→ Shop Floor
→ Quality
→ Batch Release
→ Inventory
```

## 6.5 Inventory-to-Deliver

```text
Stock
→ Reservation
→ Pick
→ Pack
→ Dispatch
→ Route
→ Tracking
→ POD
→ Delivery
```

## 6.6 Record-to-Report

```text
Transaction
→ Journal
→ Subledger
→ Reconciliation
→ Close
→ Consolidation
→ Reporting
→ Board Pack
```

## 6.7 Acquire-to-Dispose

```text
Asset Need
→ Procurement
→ Acquisition
→ Commission
→ Maintenance
→ Depreciation
→ Impairment
→ Disposal
```

## 6.8 Hire-to-Retire

```text
Workforce Need
→ Requisition
→ Candidate
→ Hiring
→ Onboarding
→ Attendance
→ Payroll
→ Performance
→ Development
→ Exit
```

## 6.9 Service-to-Resolve

```text
Case
→ Classification
→ SLA
→ Assignment
→ Work Order
→ Parts / Labour
→ Resolution
→ Customer Confirmation
→ Billing / Warranty
```

## 6.10 Product Idea-to-Retirement

```text
Idea
→ R&D
→ Specification
→ Prototype
→ Costing
→ Compliance
→ PLM Revision
→ Production
→ PIM Publication
→ Market
→ Change
→ End-of-Life
```

---

# 7. MODULE SPECIFICATION STANDARD

Every module in Harvics must have all of these sections:

1. Purpose
2. Bounded context
3. Business capabilities
4. Actors
5. Ownership
6. Dependencies
7. Entities
8. Field-level data model
9. Relationships
10. Invariants
11. State machines
12. Commands
13. Queries
14. APIs
15. Request schemas
16. Response schemas
17. Events
18. Event payloads
19. Consumers
20. Workflows
21. Permissions
22. Governance
23. AI
24. Data Ocean
25. Integrations
26. Notifications
27. Audit
28. UI
29. KPIs
30. Search
31. Bulk actions
32. Error states
33. Retry/idempotency
34. Security
35. Compliance
36. Observability
37. Tests
38. Seed/migration
39. Acceptance criteria
40. Production gate

A module is incomplete if material sections are missing.

---

# 8. ENTITY DESIGN STANDARD

Every material entity must define:

```text
id
tenantId
createdAt
updatedAt
createdBy
updatedBy
version
status
```

where appropriate.

Financial objects additionally require:

```text
currency
amountMinor
exchangeRate
source
```

Do not force fields where semantically inappropriate; use the domain model.

Every aggregate must identify:

- aggregate root
- child entities
- invariants
- allowed transitions
- commands
- events

---

# 9. STATE MACHINE STANDARD

Do not model workflows as a pile of booleans.

Example Purchase Order:

```text
DRAFT
 ↓
PENDING_APPROVAL
 ↓
APPROVED
 ↓
SENT
 ↓
ACKNOWLEDGED
 ↓
PARTIALLY_RECEIVED
 ↓
RECEIVED
 ↓
CLOSED
```

Possible exception states:

```text
REJECTED
CANCELLED
ON_HOLD
DISPUTED
```

Every state transition must have:

- actor
- reason where required
- timestamp
- audit record
- permitted previous states
- emitted event

---

# 10. API STANDARD

Every mutation:

```text
Auth
→ Tenant
→ Permission
→ Validation
→ Domain Rules
→ Governance
→ Transaction
→ Audit
→ Event
```

Use typed schemas.

Recommended shape:

```json
{
  "success": true,
  "data": {},
  "meta": {},
  "auditId": "uuid"
}
```

Failure:

```json
{
  "success": false,
  "error": {
    "code": "DOMAIN_RULE_FAILED",
    "message": "Human-readable explanation",
    "details": {}
  },
  "auditId": "uuid"
}
```

---

# 11. EVENT STANDARD

Event naming:

```text
<aggregate>.<past-tense-action>
```

Examples:

```text
purchase.requested
purchase.order.approved
goods.receipt.created
invoice.matched
payment.authorized
payment.settled
shipment.dispatched
delivery.completed
batch.released
contract.signed
```

Every event contains:

```json
{
  "eventId": "uuid",
  "eventType": "purchase.order.approved",
  "occurredAt": "ISO-8601",
  "tenantId": "uuid",
  "actorId": "uuid",
  "aggregateType": "PurchaseOrder",
  "aggregateId": "uuid",
  "correlationId": "uuid",
  "version": 1,
  "data": {}
}
```

---

# 12. IDEMPOTENCY

Any operation that can be retried must support idempotency.

Examples:

- payments
- refunds
- payouts
- webhooks
- order creation
- invoice posting
- inventory movements
- shipment booking
- notifications

Never create a second financial transaction because a provider or browser retried the request.

---

# 13. MULTI-TENANCY

Every tenant-sensitive operation must establish:

```text
tenantId
→ organisation
→ user
→ roles
→ permissions
```

Tenant isolation must exist at:

- API
- service
- query
- database
- cache
- object storage
- search
- events

Never trust tenantId supplied by an untrusted client without deriving/validating it from authenticated context.

---

# 14. MASTER DATA MANAGEMENT

MDM is a platform capability.

Canonical master objects:

- Party
- Customer
- Supplier
- Product
- SKU
- Location
- Organisation
- Employee
- Currency
- Tax jurisdiction
- UOM
- Account

MDM must support:

- deduplication
- survivorship
- golden record
- external identifiers
- merge
- split
- change history
- approval
- stewardship
- validation

---

# 15. PRODUCT ARCHITECTURE

## 15.1 PLM

```text
Idea
→ Concept
→ Specification
→ Prototype
→ Review
→ Revision
→ Approval
→ Production Release
→ Change Order
→ Retirement
```

Entities:

- ProductConcept
- ProductSpecification
- ProductRevision
- EngineeringChangeOrder
- Formula
- PackagingSpecification
- ProductLifecycle

## 15.2 PIM

Owns the commercial publication record:

- description
- attributes
- imagery
- packaging
- ingredients
- nutrition
- multilingual content
- country claims
- GTIN/EAN
- HS classification
- channel content

PLM owns product engineering truth.

PIM owns channel/commercial content.

---

# 16. PROCUREMENT / PURCHASE

This is a first-class domain.

Entities:

- PurchaseRequest
- PurchaseRequestLine
- Approval
- RFQ
- RFQLine
- SupplierQuote
- SupplierQuoteLine
- QuoteComparison
- PurchaseOrder
- PurchaseOrderLine
- GoodsReceipt
- GoodsReceiptLine
- PurchaseReturn
- SupplierInvoice
- MatchResult
- SupplierScore

Workflow:

```text
Need
→ PR
→ Approval
→ RFQ
→ Quotes
→ Comparison
→ Supplier Selection
→ PO
→ GRN
→ Quality
→ Invoice
→ 3-Way Match
→ Governance
→ Payment
```

AI:

- supplier scoring
- quote comparison
- price anomaly
- demand recommendation
- procurement opportunity detection

Never allow AI to approve or pay without the governed authority required by policy.

---

# 17. ORDER MANAGEMENT

Order Management is distinct from CRM.

CRM owns:

```text
relationship
lead
opportunity
quote
```

Order Management owns:

```text
confirmed commercial demand
allocation
holds
fulfilment
changes
cancellation
backorder
```

This becomes the orchestration layer between:

```text
CRM
Inventory
Manufacturing
Logistics
Finance
Customer Service
```

---

# 18. SUPPLY PLANNING / S&OP

Capabilities:

- demand forecast
- demand sensing
- supply forecast
- inventory policy
- safety stock
- MRP
- capacity
- scenario planning
- allocation
- exception management
- S&OP cycle

Inputs:

- historical orders
- pipeline
- promotions
- seasonality
- weather where applicable
- market signals
- inventory
- supplier lead times
- production capacity

Outputs:

- procurement recommendations
- production plan
- inventory targets
- supply exceptions

---

# 19. MANUFACTURING

Core:

- BOM
- BOM revision
- formula
- MRP
- production order
- work centre
- operation
- shop-floor event
- yield
- batch
- subcontracting
- HACCP
- allergen
- release

Quality must be capable of blocking batch release.

---

# 20. INVENTORY / WMS

Support:

- warehouse
- zone
- bin
- stock balance
- batch
- lot
- serial
- UOM
- reservation
- transfer
- receipt
- issue
- pick
- pack
- FEFO/FIFO/LIFO according to policy
- consignment
- reorder
- dead stock

Inventory movements are immutable business events.

---

# 21. QUALITY

Quality gates:

```text
Receipt
→ Inspection
→ Result
→ Accept / Reject / Hold
```

Manufacturing:

```text
Production
→ QC
→ COA
→ Batch Release / Block
```

Quality entities:

- InspectionPlan
- Inspection
- Result
- NCR
- CAPA
- COA
- Recall
- Audit
- LabResult
- Specification

---

# 22. LOGISTICS / TMS

Capabilities:

- freight order
- route
- carrier
- fleet
- vehicle
- driver
- GPS
- ETA
- temperature
- dock scheduling
- POD
- SLA
- returns

AI:

- route optimisation
- ETA prediction
- customs-delay prediction
- exception detection

---

# 23. SHIPPING / GLOBAL TRADE

Capabilities:

- booking
- container
- BL
- multimodal
- Incoterms
- HS code
- landed cost
- customs declaration
- sanctions
- FTA
- LC

Trade compliance must remain configurable by jurisdiction and source.

Do not invent legal rules.

---

# 24. FINANCE

Finance owns accounting truth.

Capabilities:

- chart of accounts
- GL
- AR
- AP
- cost centres
- invoices
- payments
- credit
- period close
- reconciliation
- reporting

No AI or operational module may bypass ledger controls.

---

# 25. TREASURY

Capabilities:

- bank register
- bank statement ingestion
- reconciliation
- cash position
- payment factory
- cash pooling
- debt
- hedge
- FX exposure

---

# 26. HPAY

HPay is the financial infrastructure layer.

Source-defined V1:

P0:
- identity
- KYC/KYB
- accounts
- wallets
- double-entry ledger
- payments
- payment methods
- merchant onboarding
- checkout
- payouts
- refunds
- admin
- webhooks

P1:
- settlement
- risk

P2:
- read-only Harvey financial queries

Financial invariants:

- BIGINT minor units
- immutable double-entry ledger
- UUIDs
- UTC
- ISO 4217
- idempotency
- reconciliation

HPay is not to be represented as a bank.

---

# 27. TAX / FX

Tax:

- jurisdiction
- tax rule
- rate
- exemption
- registration
- transaction

FX:

- source
- rate
- quote
- conversion
- exposure
- revaluation

Exact country rules require authoritative data and must be configurable.

---

# 28. LEGAL / COMPLIANCE

Capabilities:

- contract lifecycle
- templates
- clauses
- redline
- e-signature
- obligations
- renewal
- legal matter
- IP
- regulatory filing
- AML/KYB
- sanctions
- counterfeit detection

---

# 29. ENTERPRISE RISK

Separate from Neural Governance.

ERM asks:

> What risk does the enterprise carry?

Capabilities:

- risk register
- risk taxonomy
- appetite
- owner
- score
- control
- mitigation
- KRI
- operational risk
- financial risk
- supply risk
- country risk
- counterparty risk
- cyber risk
- continuity risk

---

# 30. ENTERPRISE ASSET MANAGEMENT

Asset lifecycle:

```text
Plan
→ Acquire
→ Commission
→ Operate
→ Maintain
→ Repair
→ Depreciate
→ Impair
→ Dispose
```

Entities:

- Asset
- AssetClass
- AssetLocation
- MaintenancePlan
- MaintenanceWorkOrder
- Warranty
- SparePart
- AssetMeter
- DepreciationLink

---

# 31. SERVICE / FIELD OPERATIONS

Capabilities:

- case
- SLA
- service contract
- installed base
- technician
- work order
- parts
- labour
- warranty
- resolution
- customer confirmation

---

# 32. PROJECTS

Capabilities:

- project
- portfolio
- task
- milestone
- resource
- timesheet
- project cost
- project revenue
- risk
- issue
- change request
- client portal
- project health

---

# 33. HR / PAYROLL

Capabilities:

- employee master
- organisation
- position
- ATS
- onboarding
- attendance
- leave
- payroll
- LMS
- performance
- succession
- benefits
- people analytics

Jurisdictional payroll rules must be configurable.

---

# 34. MARKETING / TRADE PROMOTION

Marketing:

- campaigns
- segments
- journeys
- content
- CDP
- social
- email
- SMS
- events
- NPS
- ROI
- affiliates

Trade Promotion / Revenue:

- distributor price
- customer price
- trade discount
- rebate
- promotion
- scheme
- channel margin
- trade spend
- promotional ROI

This is strategically important for Harvics FMCG operations.

---

# 35. ESG / SUSTAINABILITY

Capabilities:

- emissions
- energy
- water
- waste
- supplier ESG
- sustainability targets
- ESG metrics
- reporting
- evidence

Exact regulatory requirements remain jurisdiction-specific.

---

# 36. R&D / INNOVATION

Capabilities:

- innovation idea
- research project
- trial
- sample
- formulation
- test
- cost
- approval
- handoff to PLM

R&D creates product knowledge.

PLM governs product lifecycle.

PIM publishes commercial product information.

---

# 37. UNIVERSE

Retain the original ten source-defined modules:

1. FunFeed
2. Harvics Mall
3. Trade Floor
4. Playroom
5. Experts Hub
6. Jobs + Travel
7. Crypto Lite
8. Harvicoins
9. HPay Fiat Wallet
10. Circle

They must not become tangled with core ERP persistence.

Use APIs/events and shared identity/HPay where appropriate.

---

# 38. DATA OCEAN

## Bronze

Raw ingestion.

## Silver

Normalised, deduplicated data.

## Gold

AI/analytics-ready data.

Source categories from the Soul architecture include:

- FX
- weather
- cultural/religious calendar
- commodities
- sanctions
- competitor intelligence
- consumer behaviour
- HS codes
- regulatory context

Every source record needs:

```text
source
ingestedAt
effectiveAt
freshness
jurisdiction
confidence where applicable
```

---

# 39. AI ENGINE

Source-defined model names include:

- demand.py
- enhanced_demand.py
- strategy.py
- price.py
- coverage.py
- sku.py
- fraud_model.py
- credit_scoring.py

Product AI includes:

- AI Territory Brief
- AI Variance Commentary
- Lead Scoring
- CPQ Pricing
- AI suggestions

Architecture:

```text
Data
→ Feature / Read Model
→ Model
→ Structured Decision
→ Confidence
→ Governance
→ Human Approval if required
→ Action
→ Audit
```

AI cannot:

- bypass permissions
- bypass governance
- write arbitrary SQL
- move money directly
- create uncontrolled ledger entries

---

# 40. HARVEY

Harvey is the intelligence/agent layer.

Harvey should use typed tools.

Example:

```text
search_customers()
get_customer()
get_open_quotes()
create_draft_quote()
request_quote_approval()
get_inventory()
get_cash_position()
get_trade_pipeline()
```

Tool execution must always respect:

```text
Identity
→ Permission
→ Tenant
→ Tool Policy
→ Governance
→ Action
→ Audit
```

Read-only intelligence can be broad.

Mutations must be narrow and explicit.

---

# 41. HARVOICE

Voice path:

```text
Audio
→ Secure session
→ Speech
→ Intent
→ Structured command
→ Permission
→ Governance
→ Domain action
→ Result
→ Voice
```

Provider credentials remain server-side.

---

# 42. GLOBALISATION / SOUL

Global context can include:

- country
- currency
- tax
- jurisdiction
- language
- timezone
- payment method
- cultural calendar
- seasonality
- compliance

Do not scatter country logic throughout UI.

Use configuration and policy.

---

# 43. NEURAL GOVERNANCE

Checks:

1. Legal
2. Budget
3. Contract
4. Security
5. Compliance

Execution:

```text
Mutation
→ Checks
→ PASS
→ Execute
```

Failure:

```text
Mutation
→ Check fails
→ Block
→ Explain
→ Escalate
```

Governance decisions must be auditable.

---

# 44. MASTER DATA

Golden records.

### Customer

```text
Party
→ Customer
→ Contacts
→ Addresses
→ Tax IDs
→ Payment Terms
→ Credit
```

### Supplier

```text
Party
→ Supplier
→ KYC/KYB
→ Certifications
→ Contracts
→ Performance
```

### Product

```text
Product
→ SKU
→ Revision
→ Packaging
→ PIM
→ Inventory
→ Quality
```

---

# 45. UI ARCHITECTURE

Harvics OS must have a consistent enterprise shell:

```text
Global Header
├── Workspace
├── Search
├── Command
├── Notifications
├── AI
├── Context
└── User

Sidebar
├── Dashboard
├── My Work
├── Commercial
├── Supply
├── Operations
├── Finance
├── People
├── Trade
├── Intelligence
├── Administration
└── Settings
```

Every domain gets:

```text
Overview
List
Detail
Create/Edit
Workflow
Reports
AI
Audit
```

Enterprise screens must support:

- search
- filters
- saved views
- sort
- pagination
- bulk actions
- export
- column configuration
- status
- ownership
- timestamps
- audit

---

# 46. UI STATE REQUIREMENT

Every production UI must explicitly represent:

```text
Loading
Empty
Populated
Saving
Success
Validation Error
Permission Denied
Not Found
Conflict
Blocked
Provider Failure
Retry
Offline/Degraded where applicable
```

Never use fake records to make an interface look complete.

---

# 47. RBAC

Permission format:

```text
<domain>.<resource>.<action>
```

Examples:

```text
procurement.purchase_order.create
procurement.purchase_order.approve
procurement.purchase_order.cancel

finance.invoice.post
finance.period.close

inventory.stock.adjust

hpay.payment.create
hpay.payment.approve

governance.policy.manage
```

Roles should be composed from permissions.

Never hard-code business roles throughout components.

---

# 48. SECURITY

Mandatory:

- secure cookies
- CSRF protection where applicable
- refresh token rotation
- password policy
- MFA
- RBAC
- session revocation
- API key rotation
- tenant isolation
- rate limiting
- audit
- secret isolation
- input validation
- output encoding
- security headers
- encryption where required
- provider credential isolation

---

# 49. DOCUMENTS

Document Vault:

- object storage
- metadata
- versioning
- access control
- presigned URLs
- retention
- audit

Document ownership must remain linked to domain records.

---

# 50. INTEGRATION / API FABRIC

External categories:

- banks
- PSPs
- customs
- carriers
- logistics
- messaging
- email
- WhatsApp
- marketplaces
- government systems
- ERP
- CRM
- EDI
- SFTP
- analytics
- AI providers

Use adapter pattern:

```text
Domain
→ Integration Contract
→ Provider Adapter
→ External System
```

Do not leak provider-specific objects into core domain models.

---

# 51. OBSERVABILITY

Every request should be traceable by:

```text
requestId
correlationId
tenantId
actorId
```

Monitor:

- latency
- errors
- queue depth
- provider failures
- DB health
- event lag
- AI latency
- payment reconciliation
- job failures
- security events

---

# 52. TESTING

Every domain:

### Unit
Business rules.

### Integration
DB + application service.

### API
Request/response contracts.

### Workflow
End-to-end value stream.

### Security
Permissions, tenancy, authentication.

### Financial
Ledger invariants and reconciliation.

### AI
Tool permissions, structured output, confidence and governance.

### UI
Critical workflows.

---

# 53. PRODUCTION GATES

## Gate 0 — Catalogue

Only documented.

## Gate 1 — Scaffold

Navigation and shell.

## Gate 2 — Domain API

Real models and APIs.

## Gate 3 — Operator UI

Real workflow UI.

## Gate 4 — Controlled

Requires:

- identity
- permissions
- tenant controls
- audit
- governance

## Gate 5 — Production

Requires:

- operational tests
- monitoring
- backup/recovery
- failure handling
- security verification
- real data workflow
- reconciliation where financial
- documented runbook

---

# 54. BUILD ORDER

Do NOT build Universe first.

## Phase 1 — Foundation

- Identity
- Tenant
- RBAC
- Audit
- Documents
- Notifications
- MDM
- Localisation
- Observability

## Phase 2 — Commercial spine

- CRM
- Product
- PIM
- Pricing
- Quote
- Contract
- Order Management

## Phase 3 — Supply / procurement

- Procurement
- Supplier
- Inventory
- WMS
- Quality
- Supply Planning

## Phase 4 — Operations

- Manufacturing
- Logistics
- Shipping/Trade
- EAM
- Service

## Phase 5 — Finance

- Ledger
- Finance
- Treasury
- Tax
- FX
- HPay

## Phase 6 — Intelligence

- Data Ocean
- AI
- Harvey
- Harvoice
- Globalisation
- Governance

## Phase 7 — Trade

- HarvicsTrade end-to-end

## Phase 8 — Universe

- Mall
- FunFeed
- Experts
- Jobs/Travel
- Trade Floor
- Playroom
- Harvicoins
- Circle
- Crypto Lite
- HPay Wallet

---

# 55. VERTICAL SLICE RULE

Cursor must prefer a complete vertical slice over a large number of empty modules.

First production slice:

```text
CRM Lead
→ Opportunity
→ Quote
→ Approval
→ Order
→ Inventory
→ Shipment
→ Invoice
→ Payment
→ Ledger
```

Second:

```text
Purchase Request
→ RFQ
→ Supplier Quote
→ PO
→ GRN
→ Invoice
→ 3-Way Match
→ Payment
```

Third:

```text
HarvicsTrade RFQ
→ Supplier
→ Verification
→ Compliance
→ Commercial
→ Logistics
→ Settlement
```

---

# 56. CURSOR CODING RULES

## Rule 1

Read the architecture before changing code.

## Rule 2

Inspect the repository before assuming implementation.

## Rule 3

Do not create duplicate domain models.

## Rule 4

Do not invent missing business rules.

## Rule 5

Do not claim an integration is live without evidence.

## Rule 6

Do not create fake dashboard data.

## Rule 7

Do not build generic CRUD when a workflow is required.

## Rule 8

Every mutation must have validation, authorisation and audit.

## Rule 9

Every financial mutation must be idempotent.

## Rule 10

AI must use typed tools.

## Rule 11

AI cannot bypass governance.

## Rule 12

Do not create a microservice merely because a module exists.

## Rule 13

Do not change database ownership without updating the architecture.

## Rule 14

Tests are part of implementation.

## Rule 15

If the requirement is unclear:

```text
UNKNOWN / TBD
```

is better than an invented assumption.

---

# 57. DEFINITION OF DONE

A feature is DONE only when:

```text
Business requirement
+
Domain model
+
Database migration
+
Application service
+
API
+
Permissions
+
Governance
+
Audit
+
Events
+
UI
+
Validation
+
Error states
+
Tests
+
Observability
+
Documentation
```

are aligned.

---

# 58. FINAL ARCHITECTURAL TEST

Before Cursor declares Harvics production-ready, ask:

### Can a real buyer:

```text
discover supplier
→ issue RFQ
→ compare suppliers
→ verify supplier
→ negotiate
→ sign contract
→ place order
→ arrange finance
→ ship
→ receive
→ reconcile
→ pay
```

### Can Harvics:

```text
record every transaction
→ preserve financial truth
→ understand the global context
→ learn from the transaction
→ predict the next decision
→ recommend the next action
→ govern the action
→ execute it
→ audit it
```

If not, Harvics is not finished.

---

# 59. SOURCE / ASSUMPTION DISCIPLINE

Every requirement should be tagged internally as:

```text
SOURCE_DEFINED
SOURCE_DERIVED
ARCHITECTURAL_INFERENCE
EXTERNALLY_BENCHMARKED
TBD
```

Never present an inference as a source fact.

Never present a target architecture as current implementation.

Never present a prototype as production.

---

# 60. FINAL DIRECTIVE TO CURSOR

Build Harvics as one coherent organism.

Do not optimise for:

- module count
- route count
- file count
- decorative UI
- generic CRUD
- microservice count

Optimise for:

- real workflows
- data ownership
- commercial transactions
- financial integrity
- governance
- operational reliability
- measurable user outcomes
- scalable architecture

The objective is not to make Harvics look large.

The objective is to make the **underlying system actually work**.
