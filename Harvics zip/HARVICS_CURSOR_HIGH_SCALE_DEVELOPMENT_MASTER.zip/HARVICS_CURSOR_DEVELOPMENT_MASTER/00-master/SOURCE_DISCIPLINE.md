# SOURCE DISCIPLINE

## Source-derived

These are explicitly present in the Harvics materials:
- 32 product modules
- Universe
- HPay
- Soul
- Data Ocean
- AI models/capabilities
- Harvoice
- Neural Governance
- HarvicsTrade workflow
- 71-module registry
- CRM as current commercial system of record in the Board Briefing
- modular-monolith-first production architecture

## Architecture expansion / external benchmark

The following were added as enterprise architecture gaps based on the global enterprise landscape and are therefore **architectural recommendations**, not claims that Harvics source files already specified them as modules:

- PLM
- EAM
- Supply Planning / S&OP
- Order Management
- Service / Field Operations
- MDM
- ERM
- ESG
- R&D / Innovation
- Retail / POS
- Trade Promotion / Revenue Management
- PIM
- Integration/API Fabric

Cursor must keep these labels distinct.

## Unknown

Where source material does not specify:
- exact legal rules
- country tax rates
- regulatory licences
- provider contracts
- approval thresholds
- exact database fields
- final endpoint naming
- current production deployment

mark `TBD` or `UNKNOWN`.

Never manufacture certainty.
