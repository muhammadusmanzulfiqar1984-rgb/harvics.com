# TEST STRATEGY

## Pyramid

```text
Unit
→ Integration
→ API Contract
→ Workflow
→ Security
→ Production Smoke
```

## Mandatory critical scenarios

### Lead-to-Cash
Create lead, qualify, quote, approve, order, allocate, ship, invoice, pay, post ledger.

### Procure-to-Pay
PR, approval, RFQ, supplier quote, PO, receipt, match, payment, ledger.

### Trade
RFQ, supplier verification, compliance, commercial agreement, logistics, settlement.

### Governance
At least one approved and one blocked mutation per governed domain.

### Financial
Double-entry balances.
Retries do not duplicate transactions.
Reconciliation detects mismatch.

### Security
Cross-tenant access fails.
Unauthorised approval fails.
Revoked session fails.
