# RBAC MATRIX

Permissions follow:

`domain.resource.action`

Examples:

procurement.purchase_request.create
procurement.purchase_order.approve
inventory.stock.adjust
quality.batch.release
finance.invoice.post
finance.period.close
hpay.payment.create
hpay.payment.approve
legal.contract.sign
governance.policy.manage

## Rules

- Deny by default.
- Server-side enforcement.
- UI visibility is not security.
- Tenant scope is mandatory.
- Approval permission is separate from create/edit.
- Financial execution permission is separate from financial viewing.
