# GOVERNANCE MATRIX

| Action class | Legal | Budget | Contract | Security | Compliance | Human gate |
|---|---:|---:|---:|---:|---:|---|
| Create normal CRM lead | — | — | — | ✓ | — | Usually no |
| Approve high-value purchase | ✓ | ✓ | ✓ | ✓ | ✓ | Yes |
| Post journal | ✓ | ✓ | — | ✓ | ✓ | Policy-dependent |
| Pay supplier | ✓ | ✓ | ✓ | ✓ | ✓ | Policy-dependent |
| Release blocked batch | ✓ | — | — | ✓ | ✓ | Yes |
| Execute payout | — | ✓ | — | ✓ | ✓ | Policy-dependent |
| Create governed trade settlement | ✓ | ✓ | ✓ | ✓ | ✓ | Policy-dependent |

Exact thresholds are TBD unless source-defined.

## Principle

Governance must produce an auditable decision:

```text
APPROVED
BLOCKED
ESCALATED
```
