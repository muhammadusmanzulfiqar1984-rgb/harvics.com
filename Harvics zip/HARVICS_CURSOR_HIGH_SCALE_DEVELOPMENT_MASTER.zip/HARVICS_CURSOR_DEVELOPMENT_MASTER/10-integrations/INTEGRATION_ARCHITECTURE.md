# INTEGRATION ARCHITECTURE

## Adapter pattern

```text
Harvics Domain
→ Internal Interface
→ Provider Adapter
→ External Provider
```

## Provider categories

- banks
- payment processors
- KYC/KYB
- sanctions
- FX
- shipping
- GPS
- messaging
- email
- WhatsApp
- storage
- AI
- analytics
- government/customs
- EDI
- SFTP

## Rules

1. Provider-specific IDs stay in integration records.
2. Core domains use internal canonical IDs.
3. Webhooks are authenticated.
4. Webhooks are idempotent.
5. Provider outages produce explicit degraded state.
6. Secrets remain server-side.
7. Every integration has health status.
