# AI / AGENT TOOL ARCHITECTURE

## Tool categories

### Read tools
- search_customer
- get_order
- get_inventory
- get_cash_position
- get_trade_pipeline
- get_supplier
- get_contract

### Draft tools
- draft_quote
- draft_purchase_request
- draft_customer_message
- draft_trade_summary

### Governed mutation tools
- approve_quote
- create_purchase_order
- reserve_inventory
- request_payment
- initiate_payout

Governed mutation tools require:

```text
AI
→ tool schema validation
→ user permission
→ tenant
→ domain validation
→ governance
→ transaction
→ audit
```

AI never receives unrestricted database access.
