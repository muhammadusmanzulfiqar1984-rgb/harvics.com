# UI surfaces

## OS chrome
`src/app/[locale]/os/layout.tsx` wraps all OS pages in OsAppShell.
Site marketing header still exists globally except hidden routes (HarvyX, Doha, Ventures, Meet).
`/os` is **not** a sealed product shell (header collision).

## CRM pages
| Route | File | Component | APIs |
|-------|------|-----------|------|
| /os/crm | os/crm/page.tsx | CrmModuleEight | W8 leads/activities/convert, W3 pipeline/deals, crm customers |
| /os/crm/smart | os/crm/smart/page.tsx | inline | W8 full AI set via Next aliases |
| /os/crm/customers | os/crm/customers/page.tsx | list | GET /api/crm/customers |
| /os/crm/customers/[id] | ... | 360 | GET customer + W8 activities?customerId |
| /os/crm/import-harvyx | ... | import | POST W8 import/harvyx (plus HarvyX list fetch) |
| /os/crm/legacy | ... | CRMDomainContent | mock KPIs |
| /os/pipeline | os/pipeline/page.tsx | kanban | W3 pipeline + deals |

## Nearby commercial
| /os/cpq | quotes vs customers GET /api/crm/customers |
| /os/distributors | customers segment=Distributor |

## Do not put on architecture slides
EnterpriseCRM on distributor/supplier portal home.
CRMConsole + /api/modules/demo.
/os/module/[id] generic factory.
OsCommandCenter sparkline (derived/synthetic).

## Portal redirects
`/[locale]/portal/[persona]/crm` → `/[locale]/os/crm`
`/[locale]/admin/portal/[persona]/crm` → `/os/crm`
