# CRM — exact as-built status

## Verdict
CRM is a **real PostgreSQL application** with overlapping APIs.
It is **not** finished quote-to-cash.
It is **not** 71 ERP modules.
It is the only OS commercial spine you can defend in a design review.

Grade: **S3 operator UI, approaching S4** (auth exists, demo tokens in dev, no Clerk on OS).

## What is built (code-backed)

### Records that persist
| Object | Table | Written by | Read by UI |
|--------|--------|------------|------------|
| Customer | Customer | POST /api/crm/customers, Wave 8 convert, demo customers | /os/crm, /os/crm/customers, 360, CPQ, distributors |
| Lead | Lead | Wave 8 + /api/crm/leads + demo leads + HarvyX import | Wave 8 UI only (classic crm/leads unused by OS pages) |
| Deal | Deal | Wave 3 POST deals, Wave 8 convert | /os/pipeline, Module 8 |
| Campaign | Campaign | /api/crm/campaigns | **no OS page** |
| Activity | CrmActivity | Wave 8 | Module 8, Smart, customer 360 |
| AI insight | CrmAiInsight | Wave 8 score | Smart timeline |
| Email draft | CrmEmailDraft | Wave 8 email-draft | Smart |
| Contact | CrmContact | **nothing** | **nothing** |

### Operator UI that is real
- `/[locale]/os/crm` — CrmModuleEight: leads (W8), pipeline (W3), customers (crm.crud), activities (W8)
- `/[locale]/os/crm/smart` — score, bulk-score, email-draft, convert, timeline
- `/[locale]/os/crm/customers` + `/customers/[id]`
- `/[locale]/os/pipeline` — Deal kanban
- `/[locale]/os/crm/import-harvyx`

### Convert flow (implemented)
Lead → find Customer by email or name, else create → create Deal stage=Qualified
→ Lead.stage=Converted → CrmActivity note.

### AI (implemented, optional)
POST score / bulk-score / email-draft / timeline summary.
If GROQ_API_KEY missing: heuristic, still writes rows.

## What looks like CRM but is not
- `EnterpriseCRM.tsx` (~6400 lines): portal overview (map, stocks, ERP chrome).
  Dedicated portal CRM routes redirect to `/os/crm`.
- `/os/crm/legacy`: invented KPIs.
- `/api/modules/demo/*`: duplicate or in-memory demo for ERP consoles.
- `/api/m/:moduleId`: generic JSON factory. Not CRM.

## Dual stacks (must unify)
1. `/api/crm/leads` vs `/api/wave8/leads` — **same Lead table, different stage enums**
2. `/api/crm/customers` vs Wave 8 convert vs `/api/modules/demo/customers`
3. Wave 8 Deal create vs Wave 3 Deal API — **same Deal table** (this part is OK if convert+W3 stay)

Classic crm lead stages: Lead, Qualified, Proposal, Negotiation, Won, Lost, Converted
Wave 8 PATCH stages:     Lead, Qualified, Proposal, Negotiation, Won, Lost, Converted
Wave 3 deal stages:      Prospecting, Qualified, Proposal, Negotiation, Closed Won, Closed Lost

## Auth (as built)
Header: `Authorization: Bearer <jwt>`
Middleware: `requireAuthScope` (`backend/src/middleware/authScope.ts`)
CRM extra: `crmPermissionGate` maps HTTP method → RBAC action on resource `crm`
Wave 8 list: role `sales_officer` sees only own leads (`ownerId = user.id`)
Demo tokens: `demo-token-company_admin` etc. **blocked outside development** unless ALLOW_DEMO_TOKENS=1
Some UI still sends `Bearer demo-token-company_admin` as fallback (dev only).

## Neural governance
Mounted on `/api/crm` (not Wave 8). PII-without-consent warning on CRM paths.
Not a proven 5-check immune system for investors.

## Not built
- Quote / order from a Deal
- CRM contact CRUD
- Campaign UI
- Clerk/SSO on OS
- Category-tree attachment to Customer/Lead
- Industry lens on CRM objects (`industryVertical` field does not exist on Lead/Customer)
- Outbound email send (drafts only)
- Deduped identity graph / Party model
