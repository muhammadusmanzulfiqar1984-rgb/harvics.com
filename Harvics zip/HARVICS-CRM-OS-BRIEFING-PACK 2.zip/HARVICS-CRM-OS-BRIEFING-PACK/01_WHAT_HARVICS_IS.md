# What Harvics is (OS intent)

## The company
Harvics is a **trade house**, not a software vendor selling 71 ERP tiles.
It operates corridors (Europe / GCC / South Asia) across **merchandise verticals**.
Public site, Energies, HarvyX, HPay, Harvoice sit **around** the OS. They are not the OS.

## The OS (from HARVICS_OS_MASTER_SPEC.md — the vision section, not the changelog)
One platform. **10 industry lenses.** One backend philosophy. One object model.

Industries:
1. FMCG
2. Textiles & Apparels
3. Commodities
4. Industrial Solutions
5. Minerals
6. Oil & Gas
7. Real Estate
8. Sourcing Solutions
9. Finance & HPAY
10. AI & Technology

### Universal object model (the real architecture decision)
Do not build 10 schemas. One schema, tagged with industryVertical:

- Party = Customer | Supplier | Tenant | Investor | Miner | Buyer | Employee
- Product = SKU | Commodity | Property | Style | Barrel | Ore | SaaS licence
- Transaction = Order | Trade | Lease | Contract | Project | Booking | Shipment
- TransactionLine
- Location = Warehouse | Mine | Property | Well | Factory | Outlet
- Document = Invoice | LC | Title deed | BL | Permit
- FinancialAccount
- ComplianceRecord
- WorkflowEvent
- AuditLog

A shirt, a villa, and a barrel are all Product.
An LC, a lease, and a PO are all Transaction.

### Intelligence (specified, not fully running)
Specified as a nervous system through every write, not “module 56”:
1. Data Ocean (world + trade signals)
2. Intelligence layer (context: currency, law, season, corridor)
3. Neural Governance (legal / budget / contract / security / compliance before action)

Moat the spec claims vs SAP/Oracle (aspiration, not current runtime):
territory attack plans, map whitespace, weather-demand, competitor stock,
counterfeit/IPR, informal FMCG, 10-industry objects, HPay/crypto settle,
one P&L across industries, GPS distributor intel.

## Category tree (HARVICS_CATEGORY_TREE_T1-T4.txt)
This is **merchandise taxonomy**, not CRM modules.

T1 Vertical (folder) → T2 Division → T3 Category → T4 Subcategory (leaf images).
T5–T8 Product family / product / variant / SKU — later, on demand.

T1 folders:
01-apparels, 02-fmcg, 03-commodities, 04-industrial, 05-minerals,
06-oil-gas, 07-real-estate, 08-sourcing, 09-finance, 10-ai-tech

CRM should eventually attach Party/Transaction to these leaves. Today it does not.

## 71 modules
`src/lib/modules/registry.ts` lists 71 names, all `status: 'live'`.
That flag was set by a **generic JSON factory** (`GenericModuleRecord` + `/api/m/:id`).
It is a catalogue. It is not 71 products.

CRM is **Module 8** in that list. Treat Module 8 as the only commercial system of record
that the OS UI actually operates.

## Build order the spec itself wanted (Teams 1–5)
1. Lock Prisma universal model
2. Auth, roles, audit, tax, FX, jobs
3. Domain APIs (finance, CRM, procurement, inventory…)
4. Intelligence loops on live data
5. Industry lenses + frontend

Code today jumped to Team 3 screens + a factory, without locking Team 1.
