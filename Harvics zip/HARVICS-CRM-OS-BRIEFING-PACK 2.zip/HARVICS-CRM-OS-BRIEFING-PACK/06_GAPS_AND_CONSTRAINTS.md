# Gaps and constraints for next architecture

## Must unify
1. One Lead API (keep Wave 8; facade or delete /api/crm/leads).
2. One Customer writer (crm.crud + convert + demo).
3. Wire Deal.customerId as a real FK.
4. Add CrmContact API or drop the model.
5. Campaigns: ship a UI or delete the API.
6. Kill demo customer/lead routes or point them at crm.crud.

## Must not pretend
- Registry 71 live
- Data Ocean gold + Kafka
- 8 FastAPI models
- Neural Governance as product
- EnterpriseCRM as CRM
- Generic factory as a module

## Natural next slice (quote-to-cash)
Deal (exists) → Quote (Wave 5 /api/wave5/quotes exists as separate commercial, not wired from Deal)
→ Order (Prisma Order exists, related to Customer)
→ Invoice / AR (finance modules exist as Wave/finance APIs; not proven closed ledger)

Do not start 71 tickets. Start:
Week 1–2: honest registry + hide legacy mocks + one lead API
Week 3–6: identity on OS (no demo token in any shared env)
Week 7–12: Deal → Quote → Order on one Customer

## Mapping to spec objects (future)
Lead/Customer → Party
Deal → Transaction (type=opportunity/deal)
Order → Transaction (type=order)
Category tree T4 id → Product classification
industryVertical → 01-apparels … 10-ai-tech

## Prompt for Gemini/ChatGPT
You are designing the NEXT CRM architecture for Harvics OS.
Input of truth is this zip (as-built APIs + models).
Harvics is a trade house OS (10 industries, universal objects).
Output: target schema (Party/Product/Transaction mapping), one API surface,
migration from current three API sets, and a 90-day quote-to-cash plan.
Do not output 71 SAP modules.
