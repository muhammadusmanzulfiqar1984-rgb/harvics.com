# Prisma CRM models (trimmed from schema.prisma)

```prisma
model Customer {
  id            String    @id @default(cuid())
  name          String
  segment       String?
  country       String?
  city          String?
  creditRating  String?
  lifetimeValue Float     @default(0)
  contactEmail  String?
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt
  invoices      Invoice[]
  orders        Order[]
}

model Lead {
  id         String    @id @default(cuid())
  company    String
  contact    String?
  email      String?
  stage      String    @default("Lead")
  value      Float     @default(0)
  source     String?
  notes      String?
  aiScore    Int?
  aiTier     String?
  aiScoredAt DateTime?
  ownerId    String?
  createdAt  DateTime  @default(now())
  updatedAt  DateTime  @updatedAt
}

model Campaign {
  id          String   @id @default(cuid())
  name        String
  type        String?
  status      String   @default("Active")
  budget      Float    @default(0)
  spent       Float    @default(0)
  leads       Int      @default(0)
  conversions Int      @default(0)
  startDate   String?
  endDate     String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

model Deal {
  id            String    @id @default(cuid())
  name          String
  customerId    String?   // no FK in schema
  ownerId       String?
  stage         String    @default("Prospecting")
  value         Float     @default(0)
  currency      String    @default("USD")
  probability   Int       @default(20)
  expectedClose DateTime?
  source        String?
  notes         String?
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt
}

model CrmContact { /* fields exist; no API; no relations enforced */ }
model CrmActivity { type, subject, body?, outcome?, leadId?, dealId?, customerId?, contactId?, ownerId?, occurredAt }
model CrmAiInsight { leadId?, dealId?, score, tier?, reasoning?, nextAction?, aiGenerated, modelName? }
model CrmEmailDraft { leadId?, dealId?, purpose, subject, body, status default "Draft", aiGenerated }
```

Notes for architects:
- Deal.customerId is a string, **not a Prisma relation** to Customer.
- Lead has no FK to Customer after convert (only stage=Converted).
- No industryVertical, no category-tree id, no Party id.
- Order/Invoice relate to Customer — quote-to-cash could hang off Customer, not yet off Deal.
