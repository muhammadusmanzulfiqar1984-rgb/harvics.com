# HARVICS CRM + OS — briefing pack for architecture models

Generated from the live codebase (not from registry “71 live” flags).
Date: 24 August 2026. Owner: Shah Tabraiz / Harvics.

## How to use
Paste `00_README.md` + `01_WHAT_HARVICS_IS.md` + `02_CRM_AS_BUILT.md` first.
Use `03_API_CATALOG.md` as the contract list.
Do not design a 71-module SAP clone. Design a trade-house OS with CRM as the commercial spine.

## Files
| File | Contents |
|------|----------|
| 01_WHAT_HARVICS_IS.md | Company + OS intent (10 industries, universal objects, category tree) |
| 02_CRM_AS_BUILT.md | Exact CRM status: what exists, what UI uses, what is fake |
| 03_API_CATALOG.md | Every CRM-related HTTP route, body, storage |
| 04_DATA_MODELS.md | Prisma models |
| 05_UI_SURFACES.md | Pages and which APIs they call |
| 06_GAPS_AND_CONSTRAINTS.md | Defects + design rules for next architecture |

## Stack (facts)
- Next.js site: Harvics website + `/[locale]/os/*`
- Express API: `backend/` mounted at `/api`, typical local port 4000
- PostgreSQL + Prisma: `prisma/schema.prisma`
- Auth on CRM: Bearer JWT (`requireAuthScope`). Demo tokens `demo-token-*` only in NODE_ENV=development
- Optional AI: Groq on Wave 8 (`GROQ_API_KEY`)
- HarvyX (`apps/api`) is a separate outreach engine. Only join is `POST /api/wave8/import/harvyx`
