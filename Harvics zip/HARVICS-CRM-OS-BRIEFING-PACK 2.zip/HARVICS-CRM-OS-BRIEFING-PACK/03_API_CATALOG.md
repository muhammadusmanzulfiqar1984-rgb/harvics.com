# CRM API catalog (source of truth = Express)

Base: `{API}/api`  (Next rewrites most `/api/*` to Express except some `/api/wave8/*` BFF.)
All CRM/W8/W3 routes below require Bearer unless noted.

Convention: `{ success: true, data }` or `{ success: true, ...pagination }`
Errors: 400 validation, 401 missing/invalid token, 404 not found, 409 already converted.

---

## A. Classic CRM — `/api/crm`
Controller: `backend/src/modules/crm/crm.crud.controller.ts`
Guards: requireAuthScope + crmPermissionGate + neuralGovernance

### GET /api/crm
Returns last 5 customers, leads, campaigns (preview snapshot).
OS UI: unused.

### GET /api/crm/summary
Computes:
- totalCustomers, totalLeads, activeCampaigns (status Active)
- totalLifetimeValue (sum)
- leadsByStage: Lead, Qualified, Proposal, Negotiation
- conversionRate from campaign conversions/leads
OS UI: unused.

### Customers
GET    /api/crm/customers
  Query: segment, country, city, page, limit (default page=1 limit=50)
  Used by: Module 8, customer list, CPQ, distributor module

POST   /api/crm/customers
  Body: { name (req), segment?, country?, city?, contactEmail? }
  Defaults: segment=Retail, creditRating=B, lifetimeValue=0

GET    /api/crm/customers/:id
  Used by: customer 360

PUT    /api/crm/customers/:id
  Body: { name?, segment?, country?, city?, contactEmail?, creditRating?, lifetimeValue? }

DELETE /api/crm/customers/:id

### Leads (classic — same Prisma Lead as Wave 8)
GET    /api/crm/leads     query: stage, source, page, limit
POST   /api/crm/leads     { company, contact?, email?, stage?, value?, source? } default stage=Lead source=Manual
GET    /api/crm/leads/:id
PUT    /api/crm/leads/:id  { company?, contact?, email?, stage?, value?, source?, notes? }
DELETE /api/crm/leads/:id
OS UI: unused (Wave 8 owns lead UX)

### Campaigns
GET    /api/crm/campaigns   query: status, type, page, limit
POST   /api/crm/campaigns   { name, type?, budget?, startDate?, endDate? } status=Active spent=0
PUT    /api/crm/campaigns/:id   raw body, no zod
DELETE /api/crm/campaigns/:id
OS UI: unused

---

## B. Wave 8 Smart CRM — `/api/wave8`
Controller: `backend/src/modules/wave8/wave8.controller.ts`
Guards: requireAuthScope + crmPermissionGate
AI: `backend/src/services/ai.service.ts` (Groq)

GET    /api/wave8/ai/health
  → { aiEnabled, provider: Groq, model, market: {locale,country,currency,timezone} }
  Next alias: GET /api/wave8/ai/health → same

GET    /api/wave8/leads
  Query: stage, tier (maps aiTier), ownerId
  sales_officer: forced ownerId = req.user.id
  take 200, order aiScore desc, createdAt desc

POST   /api/wave8/leads
  { company (req), contact?, email?, stage default Lead, value default 0, source?, notes?, ownerId? }
  ownerId defaults to req.user.id

PATCH  /api/wave8/leads/:id
  stage enum: Lead | Qualified | Proposal | Negotiation | Won | Lost | Converted

POST   /api/wave8/leads/:id/score
  Next alias: POST /api/wave8/leads/:id/score
  Writes Lead.aiScore, aiTier, aiScoredAt + CrmAiInsight

POST   /api/wave8/leads/bulk-score
  Next alias: POST /api/wave8/leads/bulk-score
  Up to 25 leads with null aiScoredAt or scored >24h ago

POST   /api/wave8/leads/:id/email-draft
  Next alias: POST .../email-draft
  Body: { purpose: follow_up|demo_request|objection_handle|thank_you, context? }
  Writes CrmEmailDraft

POST   /api/wave8/leads/:id/convert
  409 if already Converted
  Creates/links Customer + Deal (Qualified) + activity

POST   /api/wave8/import/harvyx
  Next alias: POST /api/wave8/import/harvyx
  { leads: [{ company, contact?, email?, value?, notes?, vertical?, country?, externalId? }] } 1..200
  Skip if open lead with same email; source=harvyx; notes join vertical/country/HX:id

POST   /api/wave8/activities
  type: call|email|meeting|note|task|demo
  outcome?: positive|neutral|negative|no_show
  require leadId | dealId | customerId

GET    /api/wave8/activities
  Query: leadId, dealId, customerId, type
  take 200

GET    /api/wave8/leads/:id/timeline
  Next alias: GET .../timeline
  lead + activities + insights + drafts + aiSummary

GET    /api/wave8/pipeline
  Next alias: GET /api/wave8/pipeline
  groupBy Lead.stage, Deal.stage, Lead.aiTier + totals
  Smart CRM uses this. Module 8 uses Wave 3 pipeline instead.

Market headers forwarded: x-locale, x-country, x-currency, x-timezone

---

## C. Wave 3 deals — `/api/wave3/crm`
Controller: `backend/src/modules/wave3/wave3.controller.ts`
Guard: requireAuthScope (no crmPermissionGate)

GET    /api/wave3/crm/deals        query: stage, ownerId
POST   /api/wave3/crm/deals        { name 2..160, customerId?, ownerId?, stage default Prospecting, value (req), currency AAA, probability 0-100, expectedClose?, source?, notes? }
GET    /api/wave3/crm/pipeline     per-stage count/value/weighted + deals[] + summary
POST   /api/wave3/crm/deals/:id/stage   { stage } + probability map
  Prospecting 20, Qualified 40, Proposal 60, Negotiation 80, Closed Won 100, Closed Lost 0
DELETE /api/wave3/crm/deals/:id

---

## D. Adjacent (not CRM of record)

GET /api/domains/crm/overview     scoped in-memory slice

GET/POST/DELETE /api/modules/demo/customers
GET/POST/PATCH /api/modules/demo/leads/:id/stage
DELETE /api/modules/demo/leads/:id
  Same Prisma Customer/Lead. Only CRMConsole.tsx.

GET/POST/PATCH/DELETE /api/m/:moduleId
  GenericModuleRecord JSON. Ignore for CRM design.

HarvyX apps/api: outreach/databank. No shared session with OS CRM except import payload.

---

## Call graph (production UI)

CrmModuleEight:
  GET  /api/wave8/leads
  GET  /api/wave3/crm/pipeline
  GET  /api/crm/customers?limit=200
  GET  /api/wave8/activities
  POST /api/wave8/leads
  PATCH /api/wave8/leads/:id
  POST /api/wave8/leads/:id/convert
  POST /api/wave3/crm/deals
  POST /api/wave3/crm/deals/:id/stage
  POST /api/crm/customers
  POST /api/wave8/activities

Smart CRM:
  GET  /api/wave8/leads
  GET  /api/wave8/pipeline          (Next BFF)
  GET  /api/wave8/ai/health         (Next BFF)
  GET  /api/wave8/leads/:id/timeline
  POST /api/wave8/leads
  POST /api/wave8/leads/:id/score
  POST /api/wave8/leads/bulk-score
  POST /api/wave8/leads/:id/email-draft
  POST /api/wave8/activities
  POST /api/wave8/leads/:id/convert

Pipeline page:
  GET  /api/wave3/crm/pipeline
  POST /api/wave3/crm/deals
  POST /api/wave3/crm/deals/:id/stage

Import HarvyX:
  POST /api/wave8/import/harvyx
