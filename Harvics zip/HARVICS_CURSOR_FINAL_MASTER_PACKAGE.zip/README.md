# HARVICS — FINAL CURSOR MASTER PACKAGE

## Start here
**01-FINAL-AUTHORITY/HARVICS_FINAL_CURSOR_MASTER.md**

Then, for CRM:
**02-CRM/CRM_MASTER.md**

Then:
**03-IMPLEMENTATION/** for migration and value streams.

**04-CURSOR/** contains execution and completion rules.

The `00-SOURCE-ARCHIVES` directory preserves the supplied prior architecture packages exactly as received.

### Critical architectural decision
Harvics is not to be implemented as 71 equally-live ERP modules. The detailed module inventory is a bounded-domain catalogue. Development is value-stream-first, beginning with CRM → Quote-to-Cash → Books.

### Cursor rule
Do not confuse specification with implementation. Always audit the repository before modifying or declaring status.
