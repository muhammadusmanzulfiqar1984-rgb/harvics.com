# CURSOR EXECUTION PROTOCOL

1. Read `01-FINAL-AUTHORITY/HARVICS_FINAL_CURSOR_MASTER.md`.
2. Read the affected domain constitution.
3. Inspect actual repository implementation.
4. Classify every relevant component: IMPLEMENTED/S3/S4/SPECIFIED/TARGET/UNKNOWN/SCAFFOLD/DEPRECATED/TBD.
5. Identify duplicate ownership or APIs.
6. Define the smallest coherent migration.
7. Implement domain logic server-side.
8. Verify tenant isolation and RBAC.
9. Verify governance on execution path where required.
10. Verify audit and observability.
11. Run tests.
12. Reconcile documentation and registry with actual state.
13. Never mark capability complete without evidence.
