# DEFINITION OF DONE

A material feature is complete only when applicable criteria are proven:

- real workflow works
- real database state
- server validation
- tenant isolation
- authentication
- authorisation
- idempotency where required
- immutable audit
- governance where required
- AI provenance/fallback where applicable
- event contract
- notification path where required
- failure/recovery behaviour
- observability
- unit tests
- integration tests
- workflow tests
- security tests

A page, endpoint, Prisma model, registry flag, or AI response alone is not proof of completion.
