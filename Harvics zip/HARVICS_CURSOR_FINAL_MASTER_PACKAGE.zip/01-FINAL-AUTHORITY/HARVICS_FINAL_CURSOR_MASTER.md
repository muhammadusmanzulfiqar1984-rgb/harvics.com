# HARVICS OS — FINAL CURSOR DEVELOPMENT MASTER CONSTITUTION
## As-Built → Canonical Architecture → Controlled Production

**Classification:** Confidential — Internal Build Authority  
**System:** Harvics Universe / Harvics OS / HarvicsTrade / Harvey / Data Ocean / HPay / Harvoice  
**Purpose:** Single execution authority for Cursor and engineering agents  
**Version:** FINAL MASTER — August 2026  
**Rule:** Read this document before changing architecture, schema, APIs, workflows, security, AI, UI, integrations, or module boundaries.

---

# 0. EXECUTIVE BRIEF

Harvics is **not** a 71-tile ERP clone.

The correct architecture is a unified operating organism built around:

```text
                    HARVICS UNIVERSE
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
    HARVICS OS        HARVICSTRADE       HARVICS APPS
        │                  │                  │
        └──────────────────┼──────────────────┘
                           │
                    UNIVERSAL OBJECTS
              Party / Product / Transaction
                           │
          ┌────────────────┼────────────────┐
          │                │                │
         CRM            FINANCE          OPERATIONS
      Commercial       Money/Books      Supply/Fulfilment
          │                │                │
          └────────────────┼────────────────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
      HPAY            DATA OCEAN           HARVEY
   Settlement       World/enterprise      Intelligence
        │                  │                  │
        └──────────────────┼──────────────────┘
                           │
                    NEURAL GOVERNANCE
                           │
                  GLOBALISATION / CONTEXT
```

The immediate commercial priority is:

```text
CRM
 ↓
QUOTE-TO-CASH
 ↓
BOOKS
```

The immediate technical priority is:

```text
AS-BUILT AUDIT
 ↓
REMOVE DUPLICATES
 ↓
ESTABLISH CANONICAL OWNERSHIP
 ↓
COMPLETE ONE END-TO-END COMMERCIAL SLICE
 ↓
HARDEN SECURITY / RBAC / AUDIT / GOVERNANCE
 ↓
INTEGRATE FINANCE / INVENTORY / LOGISTICS / HPAY
 ↓
SCALE INTELLIGENCE
```

**Do not build breadth before the commercial spine is coherent.**

---

# 1. DOCUMENT AUTHORITY

This package contains both source material and this final consolidation.

## 1.1 Authority hierarchy

When sources conflict:

1. Explicit current repository evidence / verified code audit
2. This Final Cursor Constitution for repository-wide architecture
3. The canonical module constitution for the affected domain
4. Existing canonical Prisma schema for implemented persistence
5. Harvics Supreme Master / Soul / Blueprint architecture
6. Detailed module architecture
7. High-scale development architecture
8. Older generated packages

For CRM, `05-CRM-SALES_MASTER.md` is the domain constitution and remains authoritative for the intended CRM target architecture.

**Important:** A specification cannot prove implementation.

Use these status labels:

- `IMPLEMENTED` — verified in code/schema and execution path
- `S2` — domain API exists
- `S3` — real operator UI exists with real data
- `S4` — controlled: auth + tenant isolation + RBAC + audit + governance + tests
- `SPECIFIED` — defined but not verified as implemented
- `TARGET` — intended future state
- `UNKNOWN` — source says it exists or should exist, but execution has not been verified
- `SCAFFOLD` — generic infrastructure only
- `DEPRECATED` — must not be extended
- `TBD` — source does not establish the decision

Never upgrade a status merely because a route, model, registry flag, or screen exists.

---

# 2. AS-BUILT REALITY OVERRIDES ASPIRATIONAL ARCHITECTURE

Cursor's August 24, 2026 code audit is the current implementation baseline for CRM.

## 2.1 Current CRM commercial spine

```text
HarvyX / manual acquisition
        ↓
      Lead
        ↓
   AI scoring
        ↓
    Activities
        ↓
   Qualification
        ↓
     Customer
        +
       Deal
        ↓
    Pipeline
```

This is the real foundation.

The next target is:

```text
Lead
 → Qualification
 → Customer
 → Deal
 → Quote / CPQ
 → Approval
 → Sales Order
 → Credit Check
 → Inventory / Fulfilment
 → Shipment / POD
 → Invoice
 → Payment
 → Ledger
 → Settlement
```

## 2.2 Current CRM technical reality

Verified audit identifies:

- Next.js App Router frontend
- `/[locale]/os/...` route structure
- Express backend under `backend/src`
- `/api` backend prefix
- some `/api/wave8/**` Next.js BFF routes
- PostgreSQL + Prisma
- Bearer JWT authentication
- `requireAuthScope` and CRM permission gates on core CRM routes
- Groq optional for AI
- Groq absence must degrade to safe non-AI behaviour, not fabricated output

Current real CRM surfaces include:

```text
/os/crm
/os/crm/smart
/os/crm/customers
/os/crm/customers/[id]
/os/pipeline
/os/crm/import-harvyx
```

Do not treat the following as CRM systems of record:

```text
EnterpriseCRM.tsx
/os/crm/legacy
/api/modules/demo/customers
/api/modules/demo/leads
generic /api/m/:id factory
```

These must not be extended as competing CRM paths.

---

# 3. CURRENT CRM DEFECT REGISTER

These defects are architectural blockers, not cosmetic issues.

## D01 — Duplicate Lead API

Current state:

```text
/api/crm/leads
/api/wave8/leads
```

Both operate against the same Lead table.

### Target

One canonical Lead API.

Preferred:

```text
/api/crm/leads
```

Wave 8 may remain a compatibility facade temporarily, but must not become a second business implementation.

---

## D02 — Conflicting Lead states

Existing code has differing stage vocabulary.

### Target canonical state machine

```text
NEW
 ↓
CONTACTED
 ↓
QUALIFIED
 ├──→ DISQUALIFIED
 └──→ CONVERTED
```

Any compatibility mapping must be explicit.

Never maintain two semantic state machines.

---

## D03 — Multiple Customer writers

Current Customer state can be reached through several paths.

### Target

Only CRM owns Customer mutation.

```text
Wave 8 / HarvyX / external source
          ↓
      CRM command
          ↓
       Customer
```

---

## D04 — Contact model without complete API

`CrmContact` exists in current Prisma but lacks a complete domain API.

### Target

Canonical `Contact` bounded context under CRM.

---

## D05 — Campaign disconnected from CRM UI

Campaign persistence exists but is not a connected CRM operating workflow.

### Target

Either:

- integrate it into the actual Marketing domain, or
- explicitly classify it as a CRM dependency / legacy feature.

Do not expand disconnected CRUD.

---

## D06 — Authentication gaps

The audit identifies:

- localStorage JWT on OS CRM
- demo-token fallback in some surfaces
- `/api/v2/*` paths with null actor scope

### Target

Enterprise authentication and authorisation must produce non-null:

```text
tenantId
actorId
actorRole / capability set
session / correlation identity
```

No production write may proceed with missing actor identity.

---

## D07 — Governance not proven on every path

A governance middleware existing in source code does not prove governance controls the mutation.

### S4 requirement

Execution trace must prove:

```text
request
→ auth
→ permission
→ governance
→ write
```

before controlled mutation.

---

## D08 — Mock business truth

Remove all fabricated business numbers from production CRM surfaces.

Examples explicitly prohibited:

```text
847 accounts
$4.82M pipeline
invented deals
invented customer counts
```

No data is better than false data.

---

# 4. UNIVERSAL OBJECT MODEL

Harvics should progressively converge around universal objects rather than multiplying equivalent domain entities.

## 4.1 Party

Represents:

- person
- company
- customer
- supplier
- distributor
- employee
- partner
- government entity

CRM may own commercial customer state, but identity relationships must not be duplicated unnecessarily.

## 4.2 Product

Represents:

- product
- SKU
- variant
- UOM
- category
- priceable item

Product Catalogue owns product master data.

CRM references Product; it does not duplicate Product authority.

## 4.3 Transaction

Represents material commercial activity:

- quote
- order
- invoice reference
- payment reference
- procurement commitment
- shipment
- return
- settlement

Domain ownership remains explicit.

---

# 5. DOMAIN ARCHITECTURE

The detailed source architecture identifies many modules. They are retained as **bounded domains**, not presented as 71 equally live ERP tiles.

## 5.1 Commercial spine

```text
CRM + Sales
HarvicsTrade
Marketing
Legal + Compliance
Product / Catalogue
```

## 5.2 Money

```text
Finance Core
HPay
FX Engine
Tax Engine
Ledger
Audit
```

## 5.3 Operations

```text
Procurement
Inventory / WMS
Manufacturing
Logistics / Shipping / Trade
Supply Planning / S&OP
PLM / PIM / R&D
EAM / Service
```

## 5.4 Enterprise support

```text
HR / Payroll
Projects
Admin / Security
Notifications
Document Vault
BI / Planning
```

## 5.5 Intelligence

```text
Harvey Engine
AI Engine
Data Ocean
Neural Governance
Globalisation
Harvoice
```

## 5.6 Universe

```text
Harvics Mall
Circle
FunFeed
Jobs / Travel
other consumer ecosystem capabilities
```

Universe capabilities must not be allowed to distort the enterprise commercial core.

---

# 6. DOMAIN OWNERSHIP LAW

Every authoritative business object has exactly one owner.

Example:

```text
CRM
Customer / Contact / Lead / Deal / Quote / SalesOrder

Finance
Invoice / AR / AP / GL / Ledger

Inventory
Stock / Reservation / Warehouse Movement

Procurement
Purchase Request / RFQ / Purchase Order / Supplier Commitment

Logistics
Shipment / Route / POD / Delivery State

HPay
Payment Intent / Payment Transaction / Settlement Reference

Legal
Contract / Clause / Obligation / Compliance Case

Product
Product / SKU / UOM / Product Master

Data Ocean
Analytical copies / facts / aggregates / feature data

Neural Governance
Governance Decision
```

No cross-domain direct writes into another domain's authoritative tables.

Use:

```text
Typed command/API
or
Domain event
```

---

# 7. BUSINESS VALUE STREAMS

## 7.1 Lead → Cash

```text
Lead
 ↓
Qualification
 ↓
Customer
 ↓
Deal
 ↓
Quote / CPQ
 ↓
Approval
 ↓
Sales Order
 ↓
Credit Check
 ↓
Inventory / Production
 ↓
Release
 ↓
Shipment
 ↓
POD
 ↓
Invoice
 ↓
Payment
 ↓
Ledger
 ↓
Settlement
 ↓
Data Ocean
 ↓
Harvey intelligence
```

This is the primary Harvics commercial highway.

---

## 7.2 Procure → Pay

```text
Need
 ↓
Purchase Request
 ↓
RFQ
 ↓
Supplier Comparison
 ↓
Vendor Approval
 ↓
Purchase Order
 ↓
Goods Receipt
 ↓
Quality
 ↓
Supplier Invoice
 ↓
3-Way Match
 ↓
Governance
 ↓
Payment
 ↓
Ledger
```

---

## 7.3 Trade

```text
Product Discovery
 ↓
RFQ
 ↓
Supplier Sourcing
 ↓
Verification
 ↓
Compliance
 ↓
Commercial Terms
 ↓
Finance
 ↓
Logistics
 ↓
Settlement
```

---

# 8. STANDARD TRANSACTION PIPELINE

Every material mutation must follow the applicable form of:

```text
1. Authentication
2. Tenant resolution
3. Authorisation
4. Input/schema validation
5. Master-data validation
6. Business invariants
7. AI advisory decision if applicable
8. Neural Governance if applicable
9. Human approval if required
10. Idempotency check
11. Atomic transactional write
12. Domain event
13. Notification
14. Immutable audit
15. Typed response
16. Observability / trace
```

Not every low-risk read needs every stage.

Every material write must use the relevant controls.

---

# 9. API ARCHITECTURE

## 9.1 Canonical API rules

- Typed request schemas
- Typed response schemas
- Consistent HTTP status codes
- Tenant derived server-side
- Capability-based permissions
- Request/correlation ID
- Structured errors
- Idempotency for material mutations
- No generic CRUD replacing domain rules

## 9.2 Standard envelope

```typescript
{
  data: T,
  meta: {
    requestId: string,
    timestamp: string
  }
}
```

List:

```typescript
{
  data: T[],
  meta: {
    requestId: string,
    timestamp: string,
    page: number,
    perPage: number,
    total: number
  }
}
```

Error:

```typescript
{
  error: {
    code: string,
    message: string,
    field?: string
  },
  meta: {
    requestId: string,
    timestamp: string
  }
}
```

---

# 10. EVENT ARCHITECTURE

Events are business facts, not commands disguised as events.

Examples:

```text
lead.created
lead.qualified
lead.converted

customer.created
deal.created
deal.updated
deal.closed_won

quote.created
quote.submitted
quote.approved
quote.rejected

sales.order.confirmed
sales.order.released
sales.order.cancelled

inventory.reservation.requested
inventory.reservation.confirmed
inventory.reservation.failed

shipment.created
shipment.delivered
pod.received

invoice.requested
invoice.created
payment.received
ledger.posted

return.created
support.ticket.created

governance.blocked
governance.escalated
```

Events must be:

- versionable
- tenant-aware
- correlated
- idempotently consumed
- observable
- auditable

---

# 11. DATABASE ARCHITECTURE

## 11.1 Principles

- PostgreSQL + Prisma remains authoritative for operational relational state where currently used.
- Every tenant-owned entity has tenant isolation.
- Use Decimal for monetary values.
- Never use floating-point for financial amounts.
- Soft delete where historical integrity requires it.
- Audit logs are append-only.
- Avoid duplicate systems of record.
- Migrations must be reversible where practical.
- Data ownership must be explicit.

## 11.2 Financial invariants

```text
Order total
= sum(line quantities × locked prices)
  − discounts
  + taxes

Credit available
= approved limit − committed/used exposure

Weighted pipeline
= deal value × probability / 100

Invoice amount
must derive from authoritative commercial/fulfilment state,
not UI input.
```

---

# 12. CRM TARGET CONSTITUTION

The uploaded CRM Master is the detailed domain constitution.

It defines the intended CRM entities:

```text
Customer
Contact
Lead
Deal
Opportunity
Quote
QuoteLine
SalesOrder
SalesOrderLine
CrmActivity
CreditLimit
PriceList
PriceListEntry
Subscription
Rebate
Return
SupportTicket
SLA
```

The detailed CRM workflows cover:

```text
Capture Lead
Qualify Lead
Convert Lead
Create Opportunity
Create Quote
Approve Quote
Create Sales Order
Release Order
Request Invoice
Handle Return
Open Support Ticket
```

The CRM constitution's full field-level schema, API contracts, workflow rules, AI, governance, RBAC, audit, failure modes, KPIs and S4 acceptance criteria are preserved in:

`05-CRM-SALES_MASTER.md`

Cursor must read that document before modifying CRM.

---

# 13. CRM MIGRATION PLAN

## Phase A — Canonicalisation

1. Select canonical Lead Prisma model.
2. Select canonical Lead API.
3. Map all legacy stage values.
4. Convert Wave 8 to facade or remove duplicate controller.
5. Establish one Customer mutation service.
6. Remove duplicate/demo CRM writers.
7. Establish canonical Contact model/API.
8. Remove mock UI data.
9. Correct registry status.

## Phase B — Commercial control

10. Qualify.
11. Convert.
12. Contact management.
13. CreditLimit.
14. Activities.
15. Customer 360.
16. HarvyX idempotent import.

## Phase C — Quote-to-Cash

17. PriceList.
18. Quote/QuoteLine.
19. Tax Engine.
20. FX Engine.
21. Quote approval.
22. SalesOrder.
23. Credit check.
24. Inventory reservation.
25. Order release.
26. Finance invoice handoff.

## Phase D — Control plane

27. Full RBAC.
28. Governance execution-path proof.
29. Immutable audit.
30. Rate limiting.
31. API tests.
32. Workflow tests.
33. Security tests.
34. Observability.

## Phase E — Intelligence

35. CPQ AI.
36. Churn.
37. Territory strategy.
38. Data Ocean ingestion.
39. Board reporting.
40. Optimisation.

---

# 14. HARVY X BOUNDARY

HarvyX is an outreach/data acquisition engine.

Correct relationship:

```text
HarvyX
  ↓
Scoped Import API
  ↓
Canonical CRM Lead
```

HarvyX does not:

- change customer state
- change deal state
- approve quotes
- create orders
- modify CRM ownership
- bypass governance

Import must support:

- externalId
- tenant scope
- idempotency
- duplicate handling
- import job audit
- source attribution
- failure/retry
- batch limits

---

# 15. AI ARCHITECTURE

AI is an advisory/intelligence layer, not a hidden business database.

## 15.1 Allowed AI actions

```text
score
classify
recommend
forecast
draft
summarise
prioritise
detect anomaly
propose action
```

## 15.2 Restricted actions

AI must not directly:

- write arbitrary SQL
- initiate payment
- bypass RBAC
- bypass governance
- invent inventory
- invent pricing
- invent customer records
- fabricate financial values
- silently approve controlled transactions

## 15.3 AI execution

```text
Business request
 ↓
Intent
 ↓
Typed tool
 ↓
Validated context
 ↓
AI inference
 ↓
Structured output
 ↓
Confidence / provenance
 ↓
Governance
 ↓
Human approval if required
 ↓
Domain command
```

## 15.4 AI failure

If a non-critical AI capability fails:

```text
null / unavailable
+
audit
+
continue if safe
```

If AI is mandatory for a regulated decision:

```text
fail closed
```

Never manufacture a substitute result.

---

# 16. DATA OCEAN

Data Ocean is not a second operational database.

Preferred flow:

```text
Operational systems
 ↓
Bronze
 ↓
Silver
 ↓
Gold
 ↓
AI / BI / strategy
```

CRM events such as:

```text
lead.created
deal.updated
sales.order.confirmed
invoice.created
payment.received
```

become analytical facts.

Gold data must preserve:

- tenant
- time
- source
- lineage
- version
- quality state

AI must know whether a signal is:

```text
live operational
or
analytical
or
stale
or
unavailable
```

---

# 17. HPAY

HPay is the financial/settlement orchestration layer.

CRM must never store raw payment credentials.

CRM may store:

```text
payment reference
transaction reference
settlement status
provider reference
```

Financial truth belongs to HPay / Finance / Ledger according to their ownership contracts.

Expected commercial flow:

```text
Sales Order
 ↓
Invoice
 ↓
Payment Intent
 ↓
HPay
 ↓
Payment Received
 ↓
Finance AR
 ↓
Ledger
 ↓
Settlement
```

Any future digital-currency capability must be separately governed and must not be silently introduced into ordinary CRM settlement logic.

---

# 18. GLOBALISATION

Every international transaction must be context-aware.

Relevant dimensions:

```text
Country
Region
Jurisdiction
Currency
Tax
Language
Timezone
Legal entity
Trade rules
Payment terms
Incoterms
Compliance
```

Do not hard-code one jurisdiction into universal business logic.

Use configuration where the source architecture requires jurisdictional variability.

Where the legal/regulatory rule is unknown:

`TBD`.

Never invent compliance rules.

---

# 19. SECURITY ARCHITECTURE

Minimum production baseline:

```text
Authentication
+
Tenant isolation
+
Capability-based authorisation
+
Input validation
+
Output filtering
+
Rate limiting
+
Secret management
+
Audit
+
Correlation IDs
+
Secure integrations
+
Least privilege
```

### Absolute rules

- Never accept tenantId from request body as authority.
- Never write audit records with null actor identity.
- Never expose secrets to frontend.
- Never store raw payment credentials in CRM.
- Never permit cross-tenant reads.
- Never treat client-side permission checks as security.
- Never use demo credentials in production.
- Never bypass governance through a second route.

---

# 20. RBAC

Permissions must be capability-based.

CRM examples:

```text
crm:lead:read
crm:lead:create
crm:lead:update
crm:lead:qualify
crm:lead:convert
crm:lead:delete

crm:customer:read
crm:customer:create
crm:customer:update
crm:customer:delete

crm:contact:*
crm:deal:*
crm:quote:create
crm:quote:submit
crm:quote:approve
crm:quote:override
crm:order:create
crm:order:release
crm:order:cancel
crm:credit:read
crm:credit:manage
crm:return:*
crm:ticket:*
crm:activity:*
```

Role mappings are configurable and must be tested.

Four-eyes approval applies to controlled transactions where policy requires separation of maker/checker.

---

# 21. NEURAL GOVERNANCE

Governance is a server-side control plane.

Relevant checks:

```text
Legal
Budget
Contract
Security
Compliance
```

Governance output:

```typescript
{
  decision: "PASS" | "BLOCK" | "ESCALATE",
  failedChecks: string[],
  explanation: string,
  decisionId: string
}
```

Governance must be:

- before controlled write
- auditable
- correlated
- deterministic for deterministic policy checks
- fail-closed where the transaction risk requires it

A UI badge is not governance.

Middleware existence is not governance.

Only an execution trace proves governance.

---

# 22. AUDIT

Every material mutation produces an append-only audit record.

Minimum:

```text
tenantId
correlationId
actor
actorRole
timestamp
action
objectType
objectId
before
after
governanceDecision
governanceDecisionId
AI model/version if applicable
AI confidence if applicable
IP / user agent where appropriate
```

Audit records:

```text
NO UPDATE
NO DELETE
NO SILENT ALTERATION
```

---

# 23. FAILURE AND RECOVERY STANDARD

| Failure | Default policy |
|---|---|
| AI scoring unavailable | continue with null |
| Tax unavailable | block quote |
| FX unavailable | block multi-currency quote |
| Governance timeout | conservative block for controlled transaction |
| Credit service unavailable | explicit credit hold |
| Inventory reservation fails | pending reservation state |
| Finance unavailable | retry + explicit pending state |
| Duplicate command | return existing idempotent result |
| External provider failure | retry / queue / escalate according to contract |

No silent success.

No hidden retry loops without observability.

---

# 24. UI / PRODUCT ARCHITECTURE

The UI represents the system. It does not manufacture it.

Rules:

- real data only
- real loading states
- real empty states
- real error states
- server-side permissions
- no fake KPIs
- no generic placeholders where a real module exists
- no duplicate CRM dashboards
- no business logic hidden only in React

The interface may be polished, but architecture comes first.

---

# 25. TESTING

Every S4 domain requires:

## Unit

- state transitions
- pricing
- credit rules
- tax rules
- permissions
- governance mapping
- idempotency

## Integration

- API routes
- Prisma transactions
- external service contracts
- events

## Workflow

At minimum:

```text
Lead
→ Qualify
→ Convert
→ Quote
→ Approve
→ Order
```

Plus:

```text
credit hold
governance block
permission failure
duplicate order
external-service failure
AI unavailable
cross-tenant access
```

## Security

Test:

- missing auth
- expired token
- wrong tenant
- wrong role
- privilege escalation
- null actor scope
- injection
- rate limits
- secret exposure

---

# 26. OBSERVABILITY

Every production transaction should carry:

```text
requestId
correlationId
tenantId
actorId
domain
action
objectId
result
duration
failure reason
```

Cross-domain trace example:

```text
CRM order
 ↓
Inventory reservation
 ↓
Logistics
 ↓
Finance invoice
 ↓
HPay payment
 ↓
Ledger
```

A failed order must be traceable across the chain.

---

# 27. MODULE DEVELOPMENT STANDARD

Every major domain specification must eventually contain:

1. Purpose
2. Position in organism
3. Boundary
4. Ownership
5. Universal-object mapping
6. Source-of-truth hierarchy
7. Honest current state
8. Entities
9. State machines
10. Workflows
11. API contracts
12. Events
13. AI
14. Governance
15. RBAC
16. Audit
17. Notifications
18. Failure/recovery
19. UI
20. KPIs
21. Security
22. Dependencies
23. Migration plan
24. Tests
25. S0–S4 acceptance criteria

Generic module descriptions are insufficient for production-critical domains.

---

# 28. BUILD PHASES

## Phase 0 — Truth

```text
Repository audit
Schema audit
Route audit
UI audit
Auth audit
Integration audit
Status reconciliation
```

Deliverable:

```text
AS-BUILT REGISTER
```

## Phase 1 — Commercial core

```text
CRM canonicalisation
Quote-to-Cash
Finance handoff
```

## Phase 2 — Fulfilment

```text
Inventory
WMS
Logistics
Production where applicable
```

## Phase 3 — Trade

```text
HarvicsTrade
Procurement
Compliance
Trade finance
Settlement
```

## Phase 4 — Control plane

```text
RBAC
Governance
Audit
Observability
Security
```

## Phase 5 — Intelligence

```text
Data Ocean
Harvey
CPQ AI
Forecasting
Strategy
```

## Phase 6 — Ecosystem

```text
Universe
consumer surfaces
social
jobs
travel
marketplace
```

Do not accelerate Phase 6 by sacrificing Phase 1–5 integrity.

---

# 29. CURSOR WORK PROTOCOL

Before editing:

```text
READ
 ↓
LOCATE
 ↓
AUDIT
 ↓
CLASSIFY
 ↓
DESIGN
 ↓
IMPLEMENT
 ↓
TEST
 ↓
VERIFY
 ↓
DOCUMENT
```

Cursor must first answer:

```text
What owns this object?
What currently implements it?
Are there duplicates?
What is the source of truth?
What is the desired state?
What migrations are required?
What security controls apply?
What events are required?
What tests prove completion?
```

If these answers are unclear, do not invent them.

---

# 30. DEFINITION OF DONE

A feature is not done because:

- a page exists
- a route returns 200
- a Prisma model exists
- a button works
- an AI response appears
- registry says "live"

A feature is done when the relevant S4 criteria are demonstrably satisfied.

```text
Functional
+
Data integrity
+
Security
+
Tenant isolation
+
RBAC
+
Audit
+
Governance
+
Observability
+
Failure handling
+
Tests
```

---

# 31. WHAT MUST NEVER HAPPEN

Cursor must never:

- build a second CRM
- create duplicate systems of record
- treat 71 modules as 71 live products
- convert a scaffold into a claimed production feature
- invent data
- invent regulatory requirements
- invent AI confidence
- allow AI to bypass controls
- trust tenantId from the client
- write null actor identity
- bypass governance
- create financial transactions without idempotency
- store raw payment credentials
- silently estimate unavailable tax
- silently use stale FX
- hide integration failures
- hard-delete financial history
- mark S4 without tests
- rewrite unrelated modules merely for aesthetic consistency

---

# 32. FINAL STRATEGIC POSITION

The architecture is strongest when Harvics is treated as:

```text
ONE OPERATING ORGANISM
```

with:

```text
UNIVERSAL OBJECTS
+
BOUNDED DOMAINS
+
COMMERCIAL VALUE STREAMS
+
GOVERNED TRANSACTIONS
+
SHARED INTELLIGENCE
```

not:

```text
A COLLECTION OF 71 SCREENS
```

The immediate proof of the architecture is not how many modules exist.

It is whether this works correctly:

```text
Lead
→ Customer
→ Deal
→ Quote
→ Approval
→ Order
→ Inventory
→ Shipment
→ Invoice
→ Payment
→ Ledger
```

with:

```text
correct ownership
correct permissions
correct governance
correct audit
correct financial integrity
correct tenant isolation
correct failure handling
correct observability
```

That is the standard.

---

# 33. PACKAGE MAP

```text
HARVICS_CURSOR_FINAL_MASTER_PACKAGE/
│
├── 00-SOURCE-ARCHIVES/
│   ├── CRM_MASTER(1).md
│   ├── MASTER_CURSOR(2).zip
│   ├── HARVICS_DETAILED_MODULE_ARCHITECTURE(2).zip
│   ├── HARVICS_CURSOR_HIGH_SCALE_DEVELOPMENT_MASTER(2).zip
│   └── HARVICS_FINAL_CURSOR_MASTER(1).zip
│
├── 01-FINAL-AUTHORITY/
│   └── HARVICS_FINAL_CURSOR_MASTER.md
│
├── 02-CRM/
│   └── CRM_MASTER.md
│
├── 03-IMPLEMENTATION/
│   ├── AS_BUILT_TO_TARGET.md
│   ├── CRM_MIGRATION_PLAN.md
│   └── VALUE_STREAMS.md
│
└── 04-CURSOR/
    ├── CURSOR_EXECUTION_PROTOCOL.md
    └── DEFINITION_OF_DONE.md
```

The source archives are preserved to prevent accidental loss of prior architecture.

The Final Master is the repository-wide execution authority.

The CRM Master is the CRM domain authority.

---

# 34. FINAL DIRECTIVE TO CURSOR

**Build the system that exists, then build the system that is specified.**

Never reverse that order.

First establish truth.

Then establish ownership.

Then eliminate duplication.

Then complete the commercial highway.

Then harden the control plane.

Then scale intelligence.

Then expand breadth.

The goal is not maximum code.

The goal is a coherent, secure, auditable, commercially executable Harvics operating system.

**END OF FINAL CURSOR DEVELOPMENT MASTER**
