# AS-BUILT → TARGET — HARVICS

## Current principle
The repository audit is authoritative for present implementation.

## CRM current spine
HarvyX/manual → Lead → AI scoring → Activity → Qualification → Customer + Deal → Pipeline.

## Canonical target
Lead → Qualification → Customer → Deal → Quote → Approval → Sales Order → Credit → Inventory → Fulfilment → Shipment/POD → Invoice → Payment → Ledger.

## Critical defects
1. Duplicate Lead APIs.
2. Conflicting Lead states.
3. Multiple Customer writers.
4. Contact model/API incompleteness.
5. Disconnected Campaign persistence.
6. Authentication/actor-scope gaps.
7. Governance execution path not fully proven.
8. Mock business KPIs.
9. Generic factory incorrectly positioned as product capability.

## Rule
Do not expand breadth until these defects are resolved or explicitly accepted as controlled technical debt.
