# HARVICS VALUE STREAMS

## Lead → Cash
Lead → Qualification → Opportunity → Quote/CPQ → Contract → Sales Order → Credit → Inventory/Production → Shipment → POD → Invoice → Payment → Ledger → Settlement

## Procure → Pay
Need → Purchase Request → RFQ → Supplier Comparison → Vendor Approval → Purchase Order → Goods Receipt → Quality → Invoice → 3-Way Match → Governance → Payment → Ledger

## Trade
Product Discovery → RFQ → Supplier Sourcing → Verification → Compliance → Finance → Logistics → Settlement

## Principle
Value streams outrank screen count. A complete governed transaction is more valuable than a large collection of disconnected CRUD surfaces.
