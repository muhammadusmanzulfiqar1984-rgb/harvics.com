# CRM MIGRATION PLAN

## 1. Canonicalisation
- Select one Lead model.
- Select `/api/crm/leads` as canonical API.
- Convert Wave 8 to compatibility facade or retire it.
- Map all legacy statuses.
- Establish one Customer command/write service.
- Remove duplicate/demo writers.
- Complete Contact API.

## 2. Commercial completion
- Qualification.
- Conversion.
- CreditLimit.
- Activities.
- Customer 360.
- HarvyX idempotent import.

## 3. Quote-to-Cash
- PriceList.
- Quote/QuoteLine.
- Tax.
- FX.
- Approval.
- SalesOrder.
- Credit.
- Inventory reservation.
- Release.
- Finance invoice handoff.

## 4. Control
- RBAC.
- Governance execution verification.
- Audit.
- Rate limiting.
- Integration tests.
- Security tests.
- Workflow tests.

## 5. Intelligence
- CPQ AI.
- Churn.
- Territory strategy.
- Data Ocean ingestion.
- Board analytics.
